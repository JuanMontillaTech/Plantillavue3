const { defineConfig } = require('@vue/cli-service')
module.exports = {
    transpileDependencies: ["@vueform"],
    // publicPath: '/minible/vue/v-light/'
}
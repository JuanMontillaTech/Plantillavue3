<script>
export default {

}
</script>

<template>
    <footer class="footer">
        <BContainer fluid>
            <BRow>
                <BCol sm="6">{{ new Date().getFullYear() }} © Minible.</BCol>
                <BCol sm="6">
                    <div class="text-sm-end d-none d-sm-block">
                        Crafted with
                        <i class="mdi mdi-heart text-danger"></i> by
                        <a href="https://themesbrand.com/" target="_blank" class="text-reset">Themesbrand</a>
                    </div>
                </BCol>
            </BRow>
        </BContainer>
    </footer>
</template>
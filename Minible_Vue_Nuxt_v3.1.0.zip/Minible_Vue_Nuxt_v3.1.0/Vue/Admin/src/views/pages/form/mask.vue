<script>
import Layout from "../../layouts/main";
import PageHeader from "@/components/page-header";
import appConfig from "@/app.config";
import { createApp } from "vue"
import { vMaska } from "maska"
/**
 * Form-mask component
 */
export default {
  components: {
    Layout,
    PageHeader,
  },
  page: {
    title: "Form Mask",
    meta: [
      {
        name: "description",
        content: appConfig.description,
      },
    ],
  },
  data() {
    return {
      title: "Form Mask",
      items: [
        {
          text: "Forms",
          href: "/",
        },
        {
          text: "Form Mask",
          active: true,
        },
      ],
      digit: "",
      zipcode: "",
      crazyzip: "",
      money: "",
      date: "",
      hour: "",
      datetime: "",
      ipaddress: "",
      cnpj: "",
      cpf: "",
      celphone: "",
      ustelephone: "",
      areacode: "",
      telephone: "",
    };
  },
  directives() {
    createApp({}).directive("maska", vMaska)
  },
  middleware: "authentication",

};
</script>

<template>
  <Layout>
    <PageHeader :title="title" :items="items" />
    <BRow>
      <BCol lg="12">
        <BCard no-body>
          <BCardBody>
            <h4 class="card-title mb-4">Example</h4>
            <BForm>
              <BRow>
                <BCol lg="6">
                  <div>
                    <div class="form-group mb-4">
                      <label for="input-date1">Date</label>
                      <input v-model="date" v-maska :data-maska="'##/##/####'" type="text" class="form-control" />
                      <span class="text-muted">e.g "dd/mm/yyyy"</span>
                    </div>
                    <div class="form-group mb-4">
                      <label>Hour</label>
                      <input v-model="hour" v-maska :data-maska="'##:##:##'" type="text" class="form-control" />
                      <span class="text-muted">e.g "hh:mm:ss"</span>
                    </div>
                    <div class="form-group mb-4">
                      <label>Date & Hour</label>
                      <input v-model="datetime" v-maska :data-maska="'##/##/#### ##:##:##'" type="text" class="form-control" />
                      <span class="text-muted">e.g "dd/mm/yyyy hh:mm:ss"</span>
                    </div>
                    <div class="form-group mb-4">
                      <label>ZIP Code</label>
                      <input v-model="zipcode" v-maska :data-maska="'#####-###'" type="text" class="form-control" />
                      <span class="text-muted">e.g "xxxxx-xxx"</span>
                    </div>
                    <div class="form-group mb-4">
                      <label>Crazy Zip Code</label>

                      <input v-model="crazyzip" v-maska :data-maska="'#-##-##-##'" type="text" class="form-control" />
                      <span class="text-muted">e.g "x-xx-xx-xx"</span>
                    </div>
                    <div class="form-group mb-4">
                      <label>Money</label>
                      <input v-model="money" v-maska :data-maska="'###.###.###.###.###,##'" type="text" class="form-control" />
                      <span class="text-muted">e.g "Your money"</span>
                    </div>
                    <div class="form-group">
                      <label>4 digit Group</label>
                      <input v-model="digit" v-maska :data-maska="'#,####,####,####'" type="text" class="form-control" />
                      <span class="text-muted">e.g. "x,xxxx,xxxx,xxxx"</span>
                    </div>
                  </div>
                </BCol>
                <BCol lg="6">
                  <div class="form-group mb-4">
                    <label>Telephone</label>
                    <input v-model="telephone" v-maska :data-maska="'####-####'" type="text" class="form-control" />
                    <span class="text-muted">e.g "xxxx-xxxx"</span>
                  </div>
                  <div class="form-group mb-4">
                    <label>Telephone with Code Area</label>
                    <input v-model="areacode" v-maska :data-maska="'(##) ####-####'" type="text" class="form-control" />
                    <span class="text-muted">e.g "(xx) xxxx-xxxx"</span>
                  </div>
                  <div class="form-group mb-4">
                    <label>US Telephone</label>
                    <input v-model="ustelephone" v-maska :data-maska="'(###) ###-####'" type="text" class="form-control" />
                    <span class="text-muted">e.g "(xxx) xxx-xxxx"</span>
                  </div>
                  <div class="form-group mb-4">
                    <label>São Paulo Celphones</label>
                    <input v-model="celphone" v-maska :data-maska="'(##) #####-####'" type="text" class="form-control" />
                    <span class="text-muted">e.g "(xx) xxxxx-xxxx"</span>
                  </div>
                  <div class="form-group mb-4">
                    <label>CPF</label>
                    <input v-model="cpf" v-maska :data-maska="'###.###.###-##'" type="text" class="form-control" />
                    <span class="text-muted">e.g "xxx.xxx.xxxx-xx"</span>
                  </div>
                  <div class="form-group mb-4">
                    <label>CNPJ</label>
                    <input v-model="cnpj" v-maska :data-maska="'##.###.###/####-##'" type="text" class="form-control" />
                    <span class="text-muted">e.g "xx.xxx.xxx/xxxx-xx"</span>
                  </div>
                  <div class="form-group mb-4">
                    <label>IP Address</label>
                    <input v-model="ipaddress" v-maska :data-maska="'###.###.###.###'" type="text" class="form-control" />
                    <span class="text-muted">e.g "xxx.xxx.xxx.xxx"</span>
                  </div>
                </BCol>
              </BRow>
            </BForm>
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>
  </Layout>
</template>

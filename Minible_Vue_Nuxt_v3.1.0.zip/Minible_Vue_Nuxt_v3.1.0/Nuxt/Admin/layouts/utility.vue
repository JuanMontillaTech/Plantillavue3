<script>
export default {
  mounted() {
    document.body.classList.add("authentication-bg");
  },
};
</script>

<template>
  <div>
    <slot />
  </div>
</template>

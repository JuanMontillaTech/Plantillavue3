<script>
/**
 * 404-component
 */
export default {};
</script>

<template>
  <div class="my-5 pt-sm-5">
    <BContainer>
      <BRow>
        <BCol md="12">
          <div class="text-center">
            <div>
              <BRow class="justify-content-center">
                <BCol sm="4">
                  <div class="error-img">
                    <img src="/images/404-error.png" alt class="img-fluid mx-auto d-block" />
                  </div>
                </BCol>
              </BRow>
            </div>
            <h4 class="text-uppercase mt-4">Sorry, page not found</h4>
            <p class="text-muted">
              It will be as simple as Occidental in fact, it will be Occidental
            </p>
            <div class="mt-5">
              <nuxt-link to="/" class="btn btn-primary">Back to Dashboard</nuxt-link>
            </div>
          </div>
        </BCol>
      </BRow>
    </BContainer>
  </div>
</template>

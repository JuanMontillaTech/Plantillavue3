export const invoiceList = [
  {
    id: "#MN0131",
    date: "10 Jul, 2020",
    name: "Connie Franco",
    amount: "$141",
    status: "Paid",
  },
  {
    id: "#MN0130",
    date: "09 Jul, 2020",
    name: "Paul Reynolds",
    amount: "$153",
    status: "Paid",
  },
  {
    id: "#MN0129",
    date: "09 Jul, 2020",
    name: "Ronald Patterson",
    amount: "$220",
    status: "Pending",
  },
  {
    id: "#MN0128",
    date: "08 Jul, 2020",
    name: "Adella Perez",
    amount: "$175",
    status: "Paid",
  },
  {
    id: "#MN0127",
    date: "07 Jul, 2020",
    name: "Theresa Mayers",
    amount: "$160",
    status: "Paid",
  },
  {
    id: "#MN0126",
    date: "06 Jul, 2020",
    name: "Michael Wallace",
    amount: "$150",
    status: "Paid",
  },
  {
    id: "#MN0125",
    date: "05 Jul, 2020",
    name: "Oliver Gonzales",
    amount: "$165",
    status: "Pending",
  },
  {
    id: "#MN0124",
    date: "05 Jul, 2020",
    name: "David Burke",
    amount: "$170",
    status: "Paid",
  },
  {
    id: "#MN0123",
    date: "04 Jul, 2020",
    name: "Willie Verner",
    amount: "$140",
    status: "Pending",
  },
  {
    id: "#MN0122",
    date: "03 Jul, 2020",
    name: "Felix Perry",
    amount: "$155",
    status: "Paid",
  },
  {
    id: "#MN0121",
    date: "02 Jul, 2020",
    name: "Virgil Kelley",
    amount: "$165",
    status: "Paid",
  },
  {
    id: "#MN0120",
    date: "02 Jul, 2020",
    name: "Matthew Lawler",
    amount: "$170",
    status: "Pending",
  },
];

export const fields = [
  {
    key: "check",
    label: "",
  },
  {
    key: "id",
    label: "Invoice Id",
    sortable: true,
  },
  {
    key: "date",
    sortable: true,
  },
  {
    key: "name",
    label: "Billing Name",
    sortable: true,
  },
  {
    key: "amount",
    sortable: true,
  },
  {
    key: "status",
    label: "Payment Status",
    sortable: true,
  },
  {
    key: "download",
    label: "Download Pdf",
  },
  "action",
];

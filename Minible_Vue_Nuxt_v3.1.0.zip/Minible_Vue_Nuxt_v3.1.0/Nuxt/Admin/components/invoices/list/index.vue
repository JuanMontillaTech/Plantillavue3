<script>
import { invoiceList, fields } from "~/components/invoices/list/utils.js";
export default {
  data() {
    return {
      invoiceList,
      totalRows: 1,
      currentPage: 1,
      perPage: 10,
      pageOptions: [10, 25, 50, 100],
      filter: null,
      filterOn: [],
      sortBy: "age",
      sortDesc: false,
      fields
    };
  },
  computed: {
    rows() {
      return this.invoiceList.length;
    }
  },
  mounted() {
    this.totalRows = this.invoiceList.length;
  },
  methods: {
    onFiltered(filteredItems) {
      this.totalRows = filteredItems.length;
      this.currentPage = 1;
    }
  }
};
</script>

<template>
  <div>
    <BRow>
      <BCol md="4">
        <div>
          <BButton variant="success" class="mb-3">
            <i class="mdi mdi-plus me-1"></i> Add Invoice
          </BButton>
        </div>
      </BCol>
    </BRow>
    <BRow>
      <BCol sm="12" md="6">
        <div id="tickets-table_length" class="dataTables_length">
          <label class="d-inline-flex align-items-center">
            Show&nbsp;
            <BFormSelect v-model="perPage" size="sm" :options="pageOptions" />&nbsp;entries
          </label>
        </div>
      </BCol>
      <BCol sm="12" md="6">
        <div id="tickets-table_filter" class="dataTables_filter text-md-end">
          <label class="d-inline-flex align-items-center">
            Search:
            <BFormInput v-model="filter" type="search" placeholder="Search..." class="form-control form-control-sm ms-2"></BFormInput>
          </label>
        </div>
      </BCol>
    </BRow>
    <div class="table-responsive mb-0">
      <BTable table-class="table table-centered datatable table-card-list" thead-tr-class="bg-transparent" :items="invoiceList" :fields="fields" responsive="sm" :per-page="perPage" :current-page="currentPage" v-model:sort-by.sync="sortBy" v-model:sort-desc.sync="sortDesc" :filter="filter" :filter-included-fields="filterOn" @filtered="onFiltered">
        <template v-slot:cell(check)="data">
          <div class="custom-control custom-checkbox text-center">
            <input type="checkbox" class="form-check-input" :id="`contacusercheck${data.item.id}`" />
          </div>
        </template>
        <template v-slot:cell(id)="data">
          <a href="#" class="nav-link fw-bold">
            {{ data.item.id }}
          </a>
        </template>

        <template v-slot:cell(status)="data">
          <div class="badge badge-pill bg-soft-success font-size-12" :class="{ 'bg-soft-warning': data.item.status === 'Pending' }">
            {{ data.item.status }}
          </div>
        </template>

        <template v-slot:cell(name)="data">
          <a href="#" class="text-body">{{ data.item.name }}</a>
        </template>
        <template v-slot:cell(download)>
          <div>
            <BButton variant="light" class="btn-sm w-xs">
              Pdf
              <i class="uil uil-download-alt ms-2"></i>
            </BButton>
          </div>
        </template>
        <template v-slot:cell(action)>
          <ul class="list-inline mb-0">
            <li class="list-inline-item">
              <a href="#" class="px-2 text-primary" v-b-tooltip.hover title="Edit">
                <i class="uil uil-pen font-size-18"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="#" class="px-2 text-danger" v-b-tooltip.hover title="Delete">
                <i class="uil uil-trash-alt font-size-18"></i>
              </a>
            </li>
          </ul>
        </template>
      </BTable>
    </div>
    <BRow>
      <BCol>
        <div class="dataTables_paginate paging_simple_numbers float-end">
          <ul class="pagination pagination-rounded">
            <BPagination v-model="currentPage" :total-rows="rows" :per-page="perPage" />
          </ul>
        </div>
      </BCol>
    </BRow>
  </div>
</template>

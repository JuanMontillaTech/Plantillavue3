<script>
import CKEditor from "~/components/common/CKEditor.vue";

/**
 * Editor component
 */
export default {
  components: {
    CKEditor
  }
};
</script>

<template>
  <div>
    <BRow>
      <BCol cols="12">
        <BCard no-body>
          <BCardBody>
            <BCardTitle>CK Editor</BCardTitle>
            <p class="card-title-desc">
              Super simple wysiwyg editor on Bootstrap
            </p>
            <CKEditor />
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>
  </div>
</template>

<script>
import DropZone from "~/components/common/Dropzone.vue";

export default {
  data() {
    return {
      galleryFiles: [],
      galleryDropzoneFile: ""
    };
  },
  methods: {
    deleteRecord(ele) {
      if (ele.id) {
        this.galleryFiles = this.galleryFiles.filter((item) => {
          return item.id != ele.id;
        });
      }
    },
    galleryDrop(e) {
      e.preventDefault();
      // this.galleryDropzoneFile = e.dataTransfer.files;
      // this.galleryFiles.push(this.galleryDropzoneFile);
    },
    gallerySelectedFile() {
      this.galleryDropzoneFile = document.querySelector(
        ".galleryDropzoneFile"
      ).files;

      const finalFile = Object.values(this.galleryDropzoneFile).map((file) => {
        return {
          name: file.name,
          lastModified: file.lastModified,
          lastModifiedDate: file.lastModifiedDate,
          webkitRelativePath: file.webkitRelativePath,
          size: file.size
        };
      });
      this.galleryFiles.push(...finalFile);
      this.galleryFiles = this.galleryFiles.map((data, index) => {
        return {
          id: index + 1,
          ...data
        };
      });
    }
  },
  components: {
    DropZone
  }
};
</script>

<template>
  <div>
    <BRow>
      <BCol lg="12">
        <BCard no-body>
          <BCardHeader>
            <BCardTitle class="mb-0">Dropzone</BCardTitle>
          </BCardHeader>

          <BCardBody>
            <p class="text-muted">
              DropzoneJS is an open source library that provides drag’n’drop
              file uploads with image previews.
            </p>
            <DropZone files="files" cloudIcon="remix" dropzoneFile="galleryDropzoneFile" :isMultiple="true" @drop.prevent="galleryDrop($event)" @change="gallerySelectedFile" @dragenter.prevent @dragover.prevent />
            <ul class="list-unstyled mb-0" id="dropzone-preview2">
              <li class="mt-2" id="dropzone-preview-list2">
                <div class="border rounded mb-1" v-for="(file, index) of galleryFiles" :key="index">
                  <div class="d-flex p-2">
                    <div class="flex-shrink-0 me-3">
                      <div class="avatar-sm bg-light rounded">
                        <img class="img-fluid rounded d-block" src="/images/new-document.png" alt="Dropzone-Image" />
                      </div>
                    </div>
                    <div class="flex-grow-1">
                      <div class="pt-1">
                        <h5 class="fs-md mb-1">
                          &nbsp;
                          {{ file.name }}
                        </h5>
                        <p class="fs-sm text-muted mb-0">
                          <strong>{{ file.size / 1024 }}</strong> KB
                        </p>
                        <strong class="error text-danger"></strong>
                      </div>
                    </div>
                    <div class="flex-shrink-0 ms-3">
                      <BButton size="sm" variant="danger" @click="() => deleteRecord(file)">Delete</BButton>
                    </div>
                  </div>
                </div>
              </li>
            </ul>
            <div class="text-center">
              <BButton variant="primary"> Send files </BButton>
            </div>
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>
  </div>
</template>

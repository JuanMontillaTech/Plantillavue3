<script>
import MarkerMap from "~/components/maps/google/components/MarkerMap.vue";
import MapType from "~/components/maps/google/components/MapType.vue";
import StreetView from "~/components/maps/google/components/StreetView.vue";
import BasicMap from "~/components/maps/google/components/BasicMap.vue";
import Polygon from "~/components/maps/google/components/Polygon.vue";
export default {
  components: {
    MarkerMap,
    MapType,
    StreetView,
    BasicMap,
    Polygon
  }
};
</script>
<template>
  <BRow>
    <BCol lg="6">
      <BCard no-body>
        <BCardBody>
          <BCardTitle>Basic</BCardTitle>
          <p class="card-title-dsec">Example of google maps.</p>
          <BasicMap />
        </BCardBody>
      </BCard>
    </BCol>
    <BCol lg="6">
      <BCard no-body>
        <BCardBody>
          <BCardTitle>Markers</BCardTitle>
          <p class="card-title-dsec">Example of google maps.</p>
          <MarkerMap />
        </BCardBody>
      </BCard>
    </BCol>
  </BRow>
  <BRow>
    <BCol lg="6">
      <BCard no-body>
        <BCardBody>
          <BCardTitle>Street View Panoramas</BCardTitle>
          <p class="card-title-dsec">Example of google maps.</p>
          <StreetView />
          <!-- Street view map -->
          <!-- <gmap-street-view-panorama
            style="height: 300px"
            :position="{ lat: 52.201272, lng: 0.11872 }"
            :pov="pov"
            :zoom="1"
            @pano_changed="updatePano"
            @pov_changed="updatePov"
          ></gmap-street-view-panorama> -->
        </BCardBody>
      </BCard>
    </BCol>
    <BCol lg="6">
      <BCard no-body>
        <BCardBody>
          <BCardTitle>Polygon Editing</BCardTitle>
          <p class="card-title-dsec">Example of google maps.</p>
          <Polygon />
        </BCardBody>
      </BCard>
    </BCol>
  </BRow>
  <BRow>
    <BCol lg="6">
      <BCard no-body>
        <BCardBody>
          <BCardTitle>Map type</BCardTitle>
          <p class="card-title-dsec">Example of google maps.</p>
          <MapType />
        </BCardBody>
      </BCard>
    </BCol>
  </BRow>
</template>

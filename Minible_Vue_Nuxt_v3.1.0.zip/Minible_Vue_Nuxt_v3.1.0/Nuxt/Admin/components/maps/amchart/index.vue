<script>
import Basic from "~/components/maps/amchart/components/Basic.vue";
import MapLine from "~/components/maps/amchart/components/MapLine.vue";
import Pacific from "~/components/maps/amchart/components/Pacific.vue";

/**
 * amcharts-map component
 */
export default {
  components: {
    Basic,
    MapLine,
    Pacific
  }
};
</script>

<template>
  <BRow>
    <BCol lg="6">
      <BCard no-body>
        <BCardBody>
          <BCardTitle>Vector With Point</BCardTitle>
          <Basic />
        </BCardBody>
      </BCard>
    </BCol>

    <BCol lg="6">
      <BCard no-body>
        <BCardBody>
          <BCardTitle>Line With Point</BCardTitle>
          <MapLine />
        </BCardBody>
      </BCard>
    </BCol>

    <BCol lg="6">
      <BCard no-body>
        <BCardBody>
          <BCardTitle>Pacific Map</BCardTitle>
          <Pacific />
        </BCardBody>
      </BCard>
    </BCol>
  </BRow>
</template>

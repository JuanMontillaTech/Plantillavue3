<template>
  <BForm class="app-search d-none d-lg-block">
    <div class="position-relative">
      <input type="text" class="form-control" :placeholder="$t('navbar.search.text')" />
      <span class="uil-search" />
    </div>
  </BForm>
</template>

<template>
  <div class="navbar-brand-box">
    <nuxt-link to="/" class="logo logo-dark">
      <span class="logo-sm">
        <img src="/images/logo-sm.png" alt="logo-sm" height="22" />
      </span>
      <span class="logo-lg">
        <img src="/images/logo-dark.png" alt="logo-dark" height="20" />
      </span>
    </nuxt-link>

    <nuxt-link to="/" class="logo logo-light">
      <span class="logo-sm">
        <img src="/images/logo-sm.png" alt="logo-sm" height="22" />
      </span>
      <span class="logo-lg">
        <img src="/images/logo-light.png" alt="logo-light" height="20" />
      </span>
    </nuxt-link>
  </div>
</template>

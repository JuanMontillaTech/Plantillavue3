<script>
import { countryOptions } from "~/components/eCommerce/checkout/utils.js";
/**
 * Checkout component
 */
export default {
  data() {
    return {
      countryOptions,
      country: 0
    };
  }
};
</script>

<template>
  <div>
    <BRow>
      <BCol cols="xl-8">
        <div class="custom-accordion">
          <BCard no-body>
            <a href="#" class="nav-link" data-toggle="collapse" v-b-toggle.checkout-billinginfo-collapse>
              <div class="p-4">
                <div class="media align-items-center d-flex justify-content-between">
                  <div class="d-flex">
                    <div class="me-3">
                      <i class="uil uil-receipt text-primary h2"></i>
                    </div>
                    <div class="media-body overflow-hidden">
                      <h5 class="font-size-16 mb-1">Billing Info</h5>
                      <p class="text-muted text-truncate mb-0">
                        Sed ut perspiciatis unde omnis iste
                      </p>
                    </div>
                  </div>
                  <i class="mdi mdi-chevron-up accor-down-icon font-size-24"></i>
                </div>
              </div>
            </a>

            <BCollapse id="checkout-billinginfo-collapse" visible>
              <div class="p-4 border-top">
                <BForm>
                  <div>
                    <BRow>
                      <BCol lg="4">
                        <div class="form-group mb-4">
                          <label for="billing-name">Name</label>
                          <input type="text" class="form-control" id="billing-name" placeholder="Enter name" />
                        </div>
                      </BCol>
                      <BCol lg="4">
                        <div class="form-group mb-4">
                          <label for="billing-email-address">Email Address</label>
                          <input type="email" class="form-control" id="billing-email-address" placeholder="Enter email" />
                        </div>
                      </BCol>
                      <BCol lg="4">
                        <div class="form-group mb-4">
                          <label for="billing-phone">Phone</label>
                          <input type="text" class="form-control" id="billing-phone" placeholder="Enter Phone no." />
                        </div>
                      </BCol>
                    </BRow>

                    <div class="form-group mb-4">
                      <label for="billing-address">Address</label>
                      <textarea class="form-control" id="billing-address" rows="3" placeholder="Enter full address"></textarea>
                    </div>

                    <BRow>
                      <BCol lg="4">
                        <div class="form-group mb-4 mb-lg-0">
                          <label>Country</label>
                          <BFormSelect v-model="country" :options="countryOptions" />
                        </div>
                      </BCol>

                      <BCol lg="4">
                        <div class="form-group mb-4 mb-lg-0">
                          <label for="billing-city">City</label>
                          <input type="text" class="form-control" id="billing-city" placeholder="Enter City" />
                        </div>
                      </BCol>

                      <BCol lg="4">
                        <div class="form-group mb-0">
                          <label for="zip-code">Zip / Postal code</label>
                          <input type="text" class="form-control" id="zip-code" placeholder="Enter Postal code" />
                        </div>
                      </BCol>
                    </BRow>
                  </div>
                </BForm>
              </div>
            </BCollapse>
          </BCard>

          <BCard no-body>
            <a href="#" class="collapsed nav-link" data-toggle="collapse" v-b-toggle.checkout-shippinginfo-collapse>
              <div class="p-4">
                <div class="media align-items-center d-flex justify-content-between">
                  <div class="d-flex">
                    <div class="me-3">
                      <i class="uil uil-truck text-primary h2"></i>
                    </div>
                    <div class="media-body overflow-hidden">
                      <h5 class="font-size-16 mb-1">Shipping Info</h5>
                      <p class="text-muted text-truncate mb-0">
                        Neque porro quisquam est
                      </p>
                    </div>
                  </div>
                  <i class="mdi mdi-chevron-up accor-down-icon font-size-24"></i>
                </div>
              </div>
            </a>

            <BCollapse id="checkout-shippinginfo-collapse">
              <div class="p-4 border-top">
                <h5 class="font-size-14 mb-3">Shipping Info</h5>
                <BRow>
                  <BCol lg="4" sm="6">
                    <BCard no-body class="border rounded active shipping-address">
                      <BCardBody>
                        <a href="#" class="float-end ms-1" data-toggle="tooltip" data-placement="top" title="Edit">
                          <i class="uil uil-pen font-size-16"></i>
                        </a>
                        <h5 class="font-size-14 mb-4">Address 1</h5>

                        <h5 class="font-size-14">James Morgan</h5>
                        <p class="mb-1">
                          1557 Sundown Lane Smithville, TX 78957
                        </p>
                        <p class="mb-0">Mo. 012-345-6789</p>
                      </BCardBody>
                    </BCard>
                  </BCol>
                  <BCol lg="4" sm="6">
                    <BCard no-body class="border rounded shipping-address">
                      <BCardBody>
                        <a href="#" class="float-end ms-1" data-toggle="tooltip" data-placement="top" title="Edit">
                          <i class="uil uil-pen font-size-16"></i>
                        </a>
                        <h5 class="font-size-14 mb-4">Address 2</h5>

                        <h5 class="font-size-14">James Morgan</h5>
                        <p class="mb-1">
                          1557 Sundown Lane Smithville, TX 78957
                        </p>
                        <p class="mb-0">Mo. 012-345-6789</p>
                      </BCardBody>
                    </BCard>
                  </BCol>
                </BRow>
              </div>
            </BCollapse>
          </BCard>

          <BCard no-body>
            <a class="collapsed nav-link" data-toggle="collapse" href="#" v-b-toggle.checkout-paymentinfo-collapse>
              <div class="p-4">
                <div class="media align-items-center d-flex justify-content-between">
                  <div class="d-flex">
                    <div class="me-3">
                      <i class="uil uil-bill text-primary h2"></i>
                    </div>
                    <div class="media-body overflow-hidden">
                      <h5 class="font-size-16 mb-1">Payment Info</h5>
                      <p class="text-muted text-truncate mb-0">
                        Duis arcu tortor, suscipit eget
                      </p>
                    </div>
                  </div>
                  <i class="mdi mdi-chevron-up accor-down-icon font-size-24"></i>
                </div>
              </div>
            </a>

            <BCollapse id="checkout-paymentinfo-collapse">
              <div class="p-4 border-top">
                <div>
                  <h5 class="font-size-14 mb-3">Payment method :</h5>

                  <BRow>
                    <BCol lg="3" sm="6">
                      <div data-toggle="collapse">
                        <label class="card-radio-label">
                          <input type="radio" name="pay-method" id="pay-methodoption1" class="card-radio-input" />

                          <span class="card-radio text-center text-truncate">
                            <i class="uil uil-postcard d-block h2 mb-3"></i>
                            Credit / Debit Card
                          </span>
                        </label>
                      </div>
                    </BCol>

                    <BCol lg="3" sm="6">
                      <div>
                        <label class="card-radio-label">
                          <input type="radio" name="pay-method" id="pay-methodoption2" class="card-radio-input" />

                          <span class="card-radio text-center text-truncate">
                            <i class="uil uil-paypal d-block h2 mb-3"></i>
                            Paypal
                          </span>
                        </label>
                      </div>
                    </BCol>

                    <BCol lg="3" sm="6">
                      <div>
                        <label class="card-radio-label">
                          <input type="radio" name="pay-method" id="pay-methodoption3" class="card-radio-input" checked />

                          <span class="card-radio text-center text-truncate">
                            <i class="uil uil-money-bill d-block h2 mb-3"></i>
                            <span>Cash on Delivery</span>
                          </span>
                        </label>
                      </div>
                    </BCol>
                  </BRow>
                </div>
              </div>
            </BCollapse>
          </BCard>
        </div>

        <BRow class="my-4">
          <BCol>
            <nuxt-link to="/ecommerce/products" class="btn btn-link text-muted">
              <i class="uil uil-arrow-left me-1"></i> Continue Shopping
            </nuxt-link>
          </BCol>
          <BCol>
            <div class="text-sm-end mt-2 mt-sm-0">
              <a href="#" class="btn btn-success">
                <i class="uil uil-shopping-cart-alt me-1"></i> Procced
              </a>
            </div>
          </BCol>
        </BRow>
      </BCol>
      <BCol cols="xl-4">
        <BCard no-body class="checkout-order-summary">
          <BCardBody>
            <div class="p-3 bg-light mb-4">
              <h5 class="font-size-16 mb-0">
                Order Summary
                <span class="float-end ms-2">#MN0124</span>
              </h5>
            </div>
            <div class="table-responsive">
              <BTableSimple class="table-centered mb-0 table-nowrap">
                <BThead>
                  <BTr>
                    <BTh class="border-top-0" style="width: 110px" scope="col">
                      Product
                    </BTh>
                    <BTh class="border-top-0" scope="col">Product Desc</BTh>
                    <BTh class="border-top-0" scope="col">Price</BTh>
                  </BTr>
                </BThead>
                <BTbody>
                  <BTr>
                    <BTh scope="row">
                      <img src="/images/product/img-1.png" alt="product-img" title="product-img" class="avatar-md" />
                    </BTh>
                    <BTd>
                      <h5 class="font-size-14 text-truncate">
                        <nuxt-link to="/ecommerce/product-detail/1" class="nav-link">Nike N012 Running Shoes</nuxt-link>
                      </h5>
                      <p class="text-muted mb-0">$ 260 x 2</p>
                    </BTd>
                    <BTd>$ 520</BTd>
                  </BTr>
                  <BTr>
                    <BTh scope="row">
                      <img src="/images/product/img-2.png" alt="product-img" title="product-img" class="avatar-md" />
                    </BTh>
                    <BTd>
                      <h5 class="font-size-14 text-truncate">
                        <nuxt-link to="/ecommerce/product-detail/1" class="nav-link">Adidas Running Shoes</nuxt-link>
                      </h5>
                      <p class="text-muted mb-0">$ 260 x 1</p>
                    </BTd>
                    <BTd>$ 260</BTd>
                  </BTr>
                  <BTr>
                    <BTd colspan="2">
                      <h5 class="font-size-14 m-0">Sub Total :</h5>
                    </BTd>
                    <BTd>$ 780</BTd>
                  </BTr>
                  <BTr>
                    <BTd colspan="2">
                      <h5 class="font-size-14 m-0">Discount :</h5>
                    </BTd>
                    <BTd>- $ 78</BTd>
                  </BTr>

                  <BTr>
                    <BTd colspan="2">
                      <h5 class="font-size-14 m-0">Shipping Charge :</h5>
                    </BTd>
                    <BTd>$ 25</BTd>
                  </BTr>
                  <BTr>
                    <BTd colspan="2">
                      <h5 class="font-size-14 m-0">Estimated Tax :</h5>
                    </BTd>
                    <BTd>$ 18.20</BTd>
                  </BTr>

                  <BTr class="bg-light">
                    <BTd colspan="2">
                      <h5 class="font-size-14 m-0">Total:</h5>
                    </BTd>
                    <BTd>$ 745.2</BTd>
                  </BTr>
                </BTbody>
              </BTableSimple>
            </div>
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>
  </div>
</template>

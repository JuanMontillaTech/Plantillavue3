<script>
import {
  productData,
  colors,
  discounts,
  customRating,
  footwear
} from "~/components/eCommerce/Products/utils.js";
import Slider from "~/components/common/Slider.vue";
/**
 * Products component
 */
export default {
  data() {
    return {
      productData,
      sliderPrice: 800,
      currentPage: 1,
      colors,
      discounts,
      customRating,
      footwear
    };
  },
  components: {
    Slider
  },
  methods: {
    valueChange(value) {
      this.sliderPrice = value;
      this.productData = productData.filter(function (product) {
        return product.newprice <= value;
      });
    }
  }
};
</script>

<template>
  <div>
    <BRow>
      <BCol lg="4" cols="xl-3">
        <BCard no-body>
          <div class="card-header bg-transparent border-bottom">
            <h5 class="mb-0">Filters</h5>
          </div>

          <div class="p-4">
            <h5 class="font-size-14 mb-3">Categories</h5>
            <div class="custom-accordion">
              <a class="text-body font-weight-semibold pb-2 d-block" data-toggle="collapse" href="#" role="button" aria-expanded="false" v-b-toggle.categories-collapse>
                <i class="mdi mdi-chevron-up accor-down-icon text-primary me-1"></i>
                Footwear
              </a>
              <BCollapse visible id="categories-collapse">
                <BCard no-body class="p-2 border shadow-none">
                  <ul class="list-unstyled categories-list mb-0">
                    <li v-for="(data, index) in footwear" :key="data" :class="index === 1 ? 'active' : ''">
                      <a href="#">
                        <i class="mdi mdi-circle-medium me-1"></i> {{ data }}
                      </a>
                    </li>
                  </ul>
                </BCard>
              </BCollapse>
            </div>
          </div>

          <div class="p-4 border-top">
            <div>
              <h5 class="font-size-14 mb-4">Price</h5>
              <Slider v-model="sliderPrice" :min="0" :max="1000" @input="valueChange" />
            </div>
          </div>

          <div class="custom-accordion">
            <div class="p-4 border-top">
              <div>
                <h5 class="font-size-14 mb-0">
                  <a href="#" class="d-block nav-link" data-toggle="collapse" v-b-toggle.filtersizes-collapse>
                    Sizes
                    <i class="mdi mdi-chevron-up float-end accor-down-icon"></i>
                  </a>
                </h5>

                <BCollapse visible id="filtersizes-collapse">
                  <div class="mt-4">
                    <div class="media justify-content-between d-flex align-items-center">
                      <div class="media-body">
                        <h5 class="font-size-15">Select Sizes</h5>
                      </div>
                      <div class="w-xs">
                        <select class="form-select">
                          <option value="1">3</option>
                          <option value="2">4</option>
                          <option value="3">5</option>
                          <option value="4">6</option>
                          <option value="5" selected>7</option>
                          <option value="6">8</option>
                          <option value="7">9</option>
                          <option value="8">10</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </BCollapse>
              </div>
            </div>

            <div class="p-4 border-top">
              <div>
                <h5 class="font-size-14 mb-0">
                  <a href="#" class="d-block nav-link" data-toggle="collapse" v-b-toggle.filterprodductcolor-collapse>
                    Colors
                    <i class="mdi mdi-chevron-up float-end accor-down-icon"></i>
                  </a>
                </h5>

                <BCollapse visible id="filterprodductcolor-collapse">
                  <div class="mt-4">
                    <div v-for="(color, index) in colors" :key="index" class="form-check mt-2">
                      <input type="checkbox" class="form-check-input" :id="'productColorCheck' + index" />
                      <label class="form-check-label" :for="'productColorCheck' + index">
                        <i class="mdi mdi-circle mx-1" :class="'text-' + color.color"></i>
                        {{ color.title }}
                      </label>
                    </div>
                  </div>
                </BCollapse>
              </div>
            </div>

            <div class="p-4 border-top">
              <div>
                <h5 class="font-size-14 mb-0">
                  <a href="#" class="d-block nav-link" data-toggle="collapse" v-b-toggle.filterproduct-color-collapse>
                    Customer Rating
                    <i class="mdi mdi-chevron-up float-end accor-down-icon"></i>
                  </a>
                </h5>

                <BCollapse visible id="filterproduct-color-collapse">
                  <div class="mt-4">
                    <div v-for="(rating, index) in customRating" :key="index" class="form-check mt-2">
                      <input type="radio" id="productratingRadio1" name="productratingRadio1" class="form-check-input" />
                      <label class="form-check-label" for="productratingRadio1">
                        {{ rating }}
                        <i class="mdi mdi-star text-warning"></i>
                        <span v-if="rating > 1">& Above</span>
                      </label>
                    </div>
                  </div>
                </BCollapse>
              </div>
            </div>

            <div class="p-4 border-top">
              <div>
                <h5 class="font-size-14 mb-0">
                  <a href="#filterproduct-discount-collapse" class="d-block nav-link" data-toggle="collapse" v-b-toggle.filterproduct-discount-collapse>
                    Discount
                    <i class="mdi mdi-chevron-up float-end accor-down-icon"></i>
                  </a>
                </h5>

                <BCollapse id="filterproduct-discount-collapse">
                  <div class="mt-4">
                    <div v-for="(discount, index) in discounts" :key="index" class="form-check mt-2">
                      <input type="radio" :id="'productDiscountRadio' + index" name="productdiscountRadio" class="form-check-input" />
                      <label class="form-check-label" :for="'productDiscountRadio' + index">{{ discount }}</label>
                    </div>
                  </div>
                </BCollapse>
              </div>
            </div>
          </div>
        </BCard>
      </BCol>

      <BCol lg="8" cols="xl-9">
        <BCard no-body>
          <BCardBody>
            <div>
              <BRow>
                <BCol md="6">
                  <div>
                    <h5>Showing result for "Shoes"</h5>
                    <ol class="breadcrumb p-0 bg-transparent mb-2">
                      <li class="breadcrumb-item">
                        <a href="#">Footwear</a>
                      </li>
                      <li class="breadcrumb-item active">Shoes</li>
                    </ol>
                  </div>
                </BCol>

                <BCol md="6">
                  <div class="form-inline float-md-end">
                    <div class="search-box ms-2">
                      <div class="position-relative">
                        <input type="text" class="form-control bg-light border-light rounded" placeholder="Search..." />
                        <i class="mdi mdi-magnify search-icon"></i>
                      </div>
                    </div>
                  </div>
                </BCol>
              </BRow>

              <ul class="nav nav-tabs nav-tabs-custom mt-3 mb-2 ecommerce-sortby-list">
                <li class="nav-item">
                  <a class="nav-link disabled fw-medium" href="#" tabindex="-1" aria-disabled="true">Sort by:</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link active" href="#">Popularity</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">Newest</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">Discount</a>
                </li>
              </ul>

              <BRow>
                <BCol sm="6" cols="xl-4" v-for="(item, index) in productData" :key="index">
                  <div class="product-box">
                    <div class="product-img pt-4 px-4">
                      <div v-if="item.discount" class="product-ribbon badge bg-danger">
                        - {{ item.discount }} %
                      </div>
                      <div v-if="item.isTrending" class="product-ribbon badge bg-warning">
                        Trending
                      </div>
                      <div class="product-wishlist">
                        <a href="#">
                          <i class="mdi mdi-heart-outline"></i>
                        </a>
                      </div>
                      <img :src="item.image" alt class="img-fluid mx-auto d-block" />
                    </div>

                    <div class="text-center product-content p-4">
                      <h5 class="mb-1">
                        <nuxt-link :to="'/ecommerce/product-detail/' + item.id" class="nav-link">{{ item.name }}</nuxt-link>
                      </h5>
                      <p class="text-muted font-size-13">{{ item.disc }}</p>

                      <h5 class="mt-3 mb-0">
                        <span class="text-muted me-2">
                          <del>${{ item.oldprice }}</del>
                        </span>
                        ${{ item.newprice }}
                      </h5>

                      <ul class="list-inline mb-0 text-muted product-color">
                        <li class="list-inline-item">Colors :</li>
                        <li class="list-inline-item" v-for="(item, index) in item.colors" :key="index">
                          <i :class="`mdi mdi-circle text-${item}`"></i>
                        </li>
                      </ul>
                    </div>
                  </div>
                </BCol>
              </BRow>
              <BRow class="mt-4">
                <BCol lg="12">
                  <BPagination v-if="productData.length > 0" class="justify-content-end" pills v-model="currentPage" :total-rows="productData.length" :per-page="6" aria-controls="my-table"></BPagination>
                </BCol>
              </BRow>
            </div>
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>
  </div>
</template>

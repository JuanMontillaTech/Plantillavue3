<script>
import { orderData } from "~/components/eCommerce/orders/utils.js";
/**
 * Orders component
 */
export default {
  data() {
    return {
      orderData,
      totalRows: 1,
      currentPage: 1,
      perPage: 10,
      pageOptions: [10, 25, 50, 100],
      filter: null,
      filterOn: [],
      sortBy: "age",
      sortDesc: false,
      fields: [
        {
          key: "check",
          label: ""
        },
        {
          key: "id",
          label: "Order Id"
        },
        {
          key: "date",
          sortable: true
        },
        {
          key: "name",
          label: "Billing Name",
          sortable: true
        },
        {
          key: "total",
          sortable: true
        },
        {
          key: "status",
          label: "Payment Status",
          sortable: true
        },
        "action"
      ]
    };
  },
  computed: {
    /**
     * Total no. of records
     */
    rows() {
      return this.orderData.length;
    }
  },
  mounted() {
    // Set the initial number of items
    this.totalRows = this.orderData.length;
  },
  methods: {
    /**
     * Search the table data with search input
     */
    onFiltered(filteredItems) {
      // Trigger pagination to update the number of buttons/pages due to filtering
      this.totalRows = filteredItems.length;
      this.currentPage = 1;
    }
  }
};
</script>

<template>
  <div>
    <BRow>
      <BCol cols="12">
        <div class="d-flex justify-content-between">
          <BButton variant="success" class="waves-effect waves-light mb-3">
            <i class="mdi mdi-plus me-1"></i> Add New Order
          </BButton>
          <BForm class="form-inline-flex d-flex mb-3">
            <label class="my-1 me-2" for="order-selectinput">Orders</label>
            <select class="form-select" id="order-selectinput">
              <option selected>All</option>
              <option value="1">Active</option>
              <option value="2">Unpaid</option>
            </select>
          </BForm>
        </div>
        <div class="ttable table-centered datatable dt-responsive nowrap table-card-list dataTable no-footer dtr-inline">
          <BRow>
            <BCol sm="12" md="6">
              <div id="tickets-table_length" class="dataTables_length">
                <label class="d-inline-flex align-items-center">
                  Show&nbsp;
                  <BFormSelect v-model="perPage" size="sm" :options="pageOptions"></BFormSelect>&nbsp;entries
                </label>
              </div>
            </BCol>
            <BCol sm="12" md="6">
              <div id="tickets-table_filter" class="dataTables_filter text-md-end">
                <label class="d-inline-flex align-items-center">
                  Search:
                  <BFormInput v-model="filter" type="search" placeholder="Search..." class="form-control form-control-sm ms-2"></BFormInput>
                </label>
              </div>
            </BCol>
          </BRow>
          <BTable table-class="table table-centered datatable table-card-list" thead-tr-class="bg-transparent" :items="orderData" :fields="fields" responsive="sm" :per-page="perPage" :current-page="currentPage" v-model:sort-by.sync="sortBy" v-model:sort-desc.sync="sortDesc" :filter="filter" :filter-included-fields="filterOn" @filtered="onFiltered">
            <template v-slot:cell(check)="data">
              <div class="custom-control custom-checkbox text-center">
                <input type="checkbox" class="form-check-input" :id="`contacusercheck${data.item.id}`" />
              </div>
            </template>
            <template v-slot:cell(id)="data">
              <a href="#" class="nav-link fw-bold">{{
                data.item.id
              }}</a>
            </template>

            <template v-slot:cell(name)="data">
              <a href="#" class="text-body">{{ data.item.name }}</a>
            </template>
            <template v-slot:cell(status)="data">
              <div class="badge badge-pill bg-soft-success font-size-12" :class="{
                'bg-soft-danger': data.item.status === 'Chargeback',
                'bg-soft-warning': data.item.status === 'unpaid'
              }">
                {{ data.item.status }}
              </div>
            </template>
            <template v-slot:cell(action)>
              <ul class="list-inline mb-0">
                <li class="list-inline-item">
                  <a href="#" class="px-2 text-primary" v-b-tooltip.hover title="Edit">
                    <i class="uil uil-pen font-size-18"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="#" class="px-2 text-danger" v-b-tooltip.hover title="Delete">
                    <i class="uil uil-trash-alt font-size-18"></i>
                  </a>
                </li>
              </ul>
            </template>
          </BTable>
        </div>
        <BRow>
          <BCol>
            <div class="dataTables_paginate paging_simple_numbers float-end">
              <ul class="pagination pagination-rounded">
                <BPagination v-model="currentPage" :total-rows="rows" :per-page="perPage" />
              </ul>
            </div>
          </BCol>
        </BRow>
      </BCol>
    </BRow>
  </div>
</template>

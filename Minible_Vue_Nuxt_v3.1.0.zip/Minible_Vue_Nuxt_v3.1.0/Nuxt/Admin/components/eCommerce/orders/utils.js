export const orderData = [
  {
    id: "#MN0132",
    date: "10 Jul, 2020",
    name: "Melvin Martin",
    total: "$142",
    status: "Paid"
  },
  {
    id: "#MN0131",
    date: "09 Jul, 2020",
    name: "Roy Michael",
    total: "$130",
    status: "Paid"
  },
  {
    id: "#MN0130",
    date: "08 Jul, 2020",
    name: "Shelby Wolf",
    total: "$123",
    status: "unpaid"
  },
  {
    id: "#MN0129",
    date: "07 Jul, 2020",
    name: "James Riddick",
    total: "$173",
    status: "Paid"
  },
  {
    id: "#MN0128",
    date: "07 Jul, 2020",
    name: "George Kwan",
    total: "$160",
    status: "Chargeback"
  },
  {
    id: "#MN0127",
    date: "06 Jul, 2020",
    name: "Kevin Patterson",
    total: "$165",
    status: "Paid"
  },
  {
    id: "#MN0126",
    date: "05 Jul, 2020",
    name: "Danny Orr",
    total: "$161",
    status: "Paid"
  },
  {
    id: "#MN0125",
    date: "04 Jul, 2020",
    name: "Sylvia Garcia",
    total: "$153",
    status: "unpaid"
  },
  {
    id: "#MN0124",
    date: "04 Jul, 2020",
    name: "Charles Denney",
    total: "$152",
    status: "Paid"
  },
  {
    id: "#MN0123",
    date: "03 Jul, 2020",
    name: "Lisa Farrell",
    total: "$167",
    status: "Paid"
  },
  {
    id: "#MN0122",
    date: "02 Jul, 2020",
    name: "Connie Franco",
    total: "$163",
    status: "Paid"
  },
  {
    id: "#MN0121",
    date: "02 Jul, 2020",
    name: "Lara Casillas",
    total: "$171",
    status: "Paid"
  }
];

<script>
import { shops } from "~/components/eCommerce/shops/utils.js";
/**
 * Shops component
 */
export default {
  data() {
    return {
      shops
    };
  }
};
</script>

<template>
  <div>
    <BRow class="mb-2">
      <BCol md="6">
        <div class="mb-3">
          <BButton variant="success"><i class="mdi mdi-plus me-2"></i> Add New</BButton>
        </div>
      </BCol>

      <BCol md="6">
        <div class="form-inline float-md-end mb-3">
          <div class="search-box ms-2">
            <div class="position-relative">
              <input type="text" class="form-control rounded border-0" placeholder="Search..." />
              <i class="mdi mdi-magnify search-icon"></i>
            </div>
          </div>
        </div>
      </BCol>
    </BRow>
    <BRow>
      <BCol cols="xl-4" sm="6" v-for="(item, index) in shops" :key="index">
        <BCard no-body>
          <BCardBody>
            <BRow no-gutters>
              <BCol cols="auto">
                <div class="avatar-sm me-4">
                  <span :class="`avatar-title bg-${item.color}-subtle text-${item.color} font-size-16 rounded-circle`">
                    {{ item.name.charAt(0) }}
                  </span>
                </div>
              </BCol>
              <BCol cols="10">
                <div class="border-bottom pb-1">
                  <h5 class="text-truncate font-size-16 mb-1">
                    <a href="#" class="nav-link">{{ item.name }}</a>
                  </h5>
                  <p class="text-muted">
                    <i class="mdi mdi-account me-1"></i> {{ item.desc }}
                  </p>
                </div>
                <BRow>
                  <BCol cols="6">
                    <div class="mt-3">
                      <p class="text-muted mb-2">Products</p>
                      <h5 class="font-size-16 mb-0">{{ item.products }}</h5>
                    </div>
                  </BCol>
                  <BCol cols="6">
                    <div class="mt-3">
                      <p class="text-muted mb-2">Wallet Balance</p>
                      <h5 class="font-size-16 mb-0">{{ item.balance }}</h5>
                    </div>
                  </BCol>
                </BRow>
              </BCol>
            </BRow>
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>

    <BRow>
      <BCol cols="xl-12">
        <div class="text-center my-3">
          <a href="#" class="text-primary"><i class="mdi mdi-loading mdi-spin font-size-20 align-middle me-2"></i>
            Load more
          </a>
        </div>
      </BCol>
    </BRow>
  </div>
</template>

<script>
import NumberInputSpinner from "~/components/common/NumberInputSpinner.vue";
/**
 * Cart component
 */
export default {
  components: {
    NumberInputSpinner
  },
  data() {
    return {
      firstSpinner: 2,
      secondSpinner: 2
    };
  }
};
</script>

<template>
  <div>
    <BRow>
      <BCol cols="xl-8">
        <BCard no-body class="border shadow-none">
          <BCardBody>
            <BRow class="border-bottom media pb-3" no-gutters>
              <BCol cols="4" md="2">
                <img src="/images/product/img-1.png" alt class="avatar-lg" />
              </BCol>
              <BCol cols="6" md="8">
                <div class="media-body align-self-center overflow-hidden">
                  <div>
                    <h5 class="text-truncate font-size-16">
                      <nuxt-link to="/ecommerce/product-detail/1" class="nav-link">Nike N012 Running Shoes</nuxt-link>
                    </h5>
                    <p class="mb-1">
                      Color :
                      <span class="fw-medium">Gray</span>
                    </p>
                    <p>
                      Size :
                      <span class="fw-medium">08</span>
                    </p>
                  </div>
                </div>
              </BCol>
              <BCol cols="2" class="text-end">
                <ul class="list-inline mb-0 font-size-16">
                  <li class="list-inline-item" v-b-tooltip.hover title="Remove">
                    <a href="#" class="text-muted px-2">
                      <i class="uil uil-trash-alt"></i>
                    </a>
                  </li>
                  <li class="list-inline-item" v-b-tooltip.hover title="Add Wishlist">
                    <a href="#" class="text-muted px-2">
                      <i class="uil uil-heart"></i>
                    </a>
                  </li>
                </ul>
              </BCol>
            </BRow>
            <div>
              <BRow>
                <BCol cols="4" md="4">
                  <div class="mt-3">
                    <p class="text-muted mb-2">Price</p>
                    <h5 class="font-size-16">$260</h5>
                  </div>
                </BCol>
                <BCol md="4">
                  <div class="mt-3">
                    <p class="text-muted mb-2">Quantity</p>
                    <div class="input-group">
                      <NumberInputSpinner :min="1" :max="100" v-model="firstSpinner" @input="firstSpinner = $event" />
                    </div>
                  </div>
                </BCol>
                <BCol md="4">
                  <div class="mt-3">
                    <p class="text-muted mb-2">Total</p>
                    <h5 class="font-size-16">$520</h5>
                  </div>
                </BCol>
              </BRow>
            </div>
          </BCardBody>
        </BCard>
        <BCard no-body class="border shadow-none">
          <BCardBody>
            <BRow>
              <BCol cols="4" md="2"><img src="/images/product/img-2.png" alt class="avatar-lg" /></BCol>
              <BCol md="8" cols="6">
                <div class="media-body align-self-center overflow-hidden">
                  <div>
                    <h5 class="text-truncate font-size-16">
                      <nuxt-link to="/ecommerce/product-detail/1" class="nav-link">Adidas Running Shoes</nuxt-link>
                    </h5>
                    <p class="mb-1">
                      Color :
                      <span class="fw-medium">Black</span>
                    </p>
                    <p>
                      Size :
                      <span class="fw-medium">09</span>
                    </p>
                  </div>
                </div>
              </BCol>
              <BCol cols="2" class="text-end">
                <ul class="list-inline mb-0 font-size-16">
                  <li class="list-inline-item" v-b-tooltip.hover title="Remove">
                    <a href="#" class="text-muted px-2">
                      <i class="uil uil-trash-alt"></i>
                    </a>
                  </li>
                  <li class="list-inline-item" v-b-tooltip.hover title="Add Wishlist">
                    <a href="#" class="text-muted px-2">
                      <i class="uil uil-heart"></i>
                    </a>
                  </li>
                </ul>
              </BCol>
            </BRow>
            <div>
              <BRow>
                <BCol md="4">
                  <div class="mt-3">
                    <p class="text-muted mb-2">Price</p>
                    <h5 class="font-size-16">$260</h5>
                  </div>
                </BCol>
                <BCol md="4">
                  <div class="mt-3">
                    <p class="text-muted mb-2">Quantity</p>
                    <div>
                      <div class="input-group">
                        <NumberInputSpinner v-model="secondSpinner" :min="1" :max="100" @input="secondSpinner = $event" />
                      </div>
                    </div>
                  </div>
                </BCol>
                <BCol md="4">
                  <div class="mt-3">
                    <p class="text-muted mb-2">Total</p>
                    <h5 class="font-size-16">$260</h5>
                  </div>
                </BCol>
              </BRow>
            </div>
          </BCardBody>
        </BCard>
        <BRow class="mt-4">
          <BCol sm="6">
            <nuxt-link to="/ecommerce/products" class="btn btn-link text-muted">
              <i class="uil uil-arrow-left me-1"></i> Continue Shopping
            </nuxt-link>
          </BCol>
          <BCol sm="6">
            <div class="text-sm-end mt-2 mt-sm-0">
              <nuxt-link to="/ecommerce/checkout" class="btn btn-success">
                <i class="uil uil-shopping-cart-alt me-1"></i> Checkout
              </nuxt-link>
            </div>
          </BCol>
        </BRow>
      </BCol>

      <BCol xl="4">
        <div class="mt-5 mt-lg-0">
          <BCard no-body class="border shadow-none">
            <div class="card-header bg-transparent border-bottom py-3 px-4">
              <h5 class="font-size-16 mb-0">
                Order Summary
                <span class="float-end">#MN0124</span>
              </h5>
            </div>
            <BCardBody class="p-4">
              <div class="table-responsive">
                <BTableSimple class="mb-0">
                  <BTbody>
                    <BTr>
                      <BTd>Sub Total :</BTd>
                      <BTd class="text-end">$ 780</BTd>
                    </BTr>
                    <BTr>
                      <BTd>Discount :</BTd>
                      <BTd class="text-end">- $ 78</BTd>
                    </BTr>
                    <BTr>
                      <BTd>Shipping Charge :</BTd>
                      <BTd class="text-end">$ 25</BTd>
                    </BTr>
                    <BTr>
                      <BTd>Estimated Tax :</BTd>
                      <BTd class="text-end">$ 18.20</BTd>
                    </BTr>
                    <BTr class="bg-light">
                      <BTh>Total :</BTh>
                      <BTd class="text-end">
                        <span class="fw-bold">$ 745.2</span>
                      </BTd>
                    </BTr>
                  </BTbody>
                </BTableSimple>
              </div>
            </BCardBody>
          </BCard>
        </div>
      </BCol>
    </BRow>
  </div>
</template>

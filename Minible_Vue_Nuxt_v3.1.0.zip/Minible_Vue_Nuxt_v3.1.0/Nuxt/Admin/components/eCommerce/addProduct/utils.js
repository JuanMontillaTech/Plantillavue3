export const categoryOptions = [
  { value: null, text: "Select" },
  { value: "EL", text: "Electronic" },
  { value: "FA", text: "Fashion" },
  { value: "FI", text: "Fitness" }
];

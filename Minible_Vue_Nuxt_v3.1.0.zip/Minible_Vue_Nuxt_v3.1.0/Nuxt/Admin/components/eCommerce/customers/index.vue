<script>
import { customersData } from "~/components/eCommerce/customers/utils.js";
/**
 * Customer component
 */
export default {
  data() {
    return {
      customersData,
      totalRows: 1,
      currentPage: 1,
      perPage: 10,
      pageOptions: [10, 25, 50, 100],
      filter: null,
      filterOn: [],
      sortBy: "age",
      sortDesc: false,
      fields: [
        {
          key: "check",
          label: ""
        },
        {
          key: "id",
          label: "Customer ID"
        },
        {
          key: "name",
          label: "Customer",
          sortable: true
        },
        {
          key: "email",
          sortable: true
        },
        {
          key: "date",
          label: "Join Date",
          sortable: true
        },
        {
          key: "status",
          label: "Status",
          sortable: true
        },
        "action"
      ]
    };
  },
  computed: {
    /**
     * Total no. of records
     */
    rows() {
      return this.customersData.length;
    }
  },
  mounted() {
    // Set the initial number of items
    this.totalRows = this.customersData.length;
  },
  methods: {
    /**
     * Search the table data with search input
     */
    onFiltered(filteredItems) {
      // Trigger pagination to update the number of buttons/pages due to filtering
      this.totalRows = filteredItems.length;
      this.currentPage = 1;
    }
  },
  middleware: "authentication"
};
</script>

<template>
  <div>
    <BRow>
      <BCol cols="12">
        <BRow class="mt-4">
          <BCol sm="12" md="6">
            <div id="tickets-table_length" class="dataTables_length">
              <label class="d-inline-flex align-items-center">
                Show&nbsp;
                <BFormSelect v-model="perPage" size="sm" :options="pageOptions" class="me-2" />&nbsp;entries
              </label>
            </div>
          </BCol>
          <BCol sm="12" md="6">
            <div id="tickets-table_filter" class="dataTables_filter text-md-end">
              <label class="d-inline-flex align-items-center">
                Search:
                <BFormInput v-model="filter" type="search" placeholder="Search..." class="form-control form-control-sm ms-2" />
              </label>
            </div>
          </BCol>
        </BRow>
        <div class="table-responsive mb-0">
          <BTable table-class="table table-centered datatable table-card-list" thead-tr-class="bg-transparent" :items="customersData" :fields="fields" responsive="sm" :per-page="perPage" :current-page="currentPage" v-model:sort-by.sync="sortBy" v-model:sort-desc.sync="sortDesc" :filter="filter" :filter-included-fields="filterOn" @filtered="onFiltered">
            <template v-slot:cell(check)="data">
              <div class="custom-control custom-checkbox text-center">
                <input type="checkbox" class="form-check-input" :id="`contacusercheck${data.item.id}`" />
              </div>
            </template>
            <template v-slot:cell(id)="data">
              <a href="#" class="nav-link fw-bold">{{
                data.item.id
              }}</a>
            </template>

            <template v-slot:cell(name)="data">
              <img v-if="data.item.profile" :src="data.item.profile" alt class="avatar-xs rounded-circle me-2" />
              <div v-if="!data.item.profile" class="avatar-xs d-inline-block me-2">
                <span class="avatar-title rounded-circle bg-light text-body">{{
                  data.item.name.charAt(0)
                }}</span>
              </div>

              <a href="#" class="text-body">{{ data.item.name }}</a>
            </template>
            <template v-slot:cell(status)="data">
              <div class="badge badge-pill bg-soft-success font-size-12" :class="{ 'bg-soft-danger': data.item.status === 'Deactive' }">
                {{ data.item.status }}
              </div>
            </template>
            <template v-slot:cell(action)>
              <ul class="list-inline mb-0">
                <li class="list-inline-item">
                  <a href="#" class="px-2 text-primary" v-b-tooltip.hover title="Edit">
                    <i class="uil uil-pen font-size-18"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="#" class="px-2 text-danger" v-b-tooltip.hover title="Delete">
                    <i class="uil uil-trash-alt font-size-18"></i>
                  </a>
                </li>
              </ul>
            </template>
          </BTable>
        </div>
        <BRow>
          <BCol>
            <div class="dataTables_paginate paging_simple_numbers float-end">
              <ul class="pagination pagination-rounded">
                <BPagination v-model="currentPage" :total-rows="rows" :per-page="perPage" />
              </ul>
            </div>
          </BCol>
        </BRow>
      </BCol>
    </BRow>
  </div>
</template>

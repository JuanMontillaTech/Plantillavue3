import Avatar2 from "~/public/images/users/avatar-2.jpg";
import Avatar3 from "~/public/images/users/avatar-3.jpg";
import Avatar4 from "~/public/images/users/avatar-4.jpg";
import Avatar6 from "~/public/images/users/avatar-6.jpg";
import Avatar7 from "~/public/images/users/avatar-7.jpg";
import Avatar8 from "~/public/images/users/avatar-7.jpg";

export const customersData = [
  {
    id: "#MN0123",
    profile: Avatar2,
    name: "William Shipp",
    email: "WilliamShipp@jourrapide.com",
    date: "14 Apr, 2020",
    status: "Active"
  },
  {
    id: "#MN0122",
    name: "Joe Hardy",
    email: "JoeHardy@dayrep.com",
    date: "14 Apr, 2020",
    status: "Active"
  },
  {
    id: "#MN0121",
    profile: Avatar3,
    name: "Thomas Hankins",
    email: "ThomasHankins@dayrep.com",
    date: "13 Apr, 2020",
    status: "Active"
  },
  {
    id: "#MN0120",
    profile: Avatar4,
    name: "Mary Frazier",
    email: "MaryFrazier@armyspy.com",
    date: "12 Apr, 2020",
    status: "Deactive"
  },
  {
    id: "#MN0119",
    name: "Sam Perry",
    email: "SamPerry@rhyta.com",
    date: "12 Apr, 2020",
    status: "Active"
  },
  {
    id: "#MN0118",
    profile: Avatar4,
    name: "Muriel Myers",
    email: "MurielMyers@rhyta.com",
    date: "09 Apr, 2020",
    status: "Deactive"
  },
  {
    id: "#MN0117",
    name: "Jessie Jacobs",
    email: "Jessie Jacobs@teleworm.com",
    date: "09 Apr, 2020",
    status: "Active"
  },
  {
    id: "#MN0116",
    profile: Avatar6,
    name: "Edward King",
    email: "EdwardKing@teleworm.com",
    date: "08 Apr, 2020",
    status: "Active"
  },
  {
    id: "#MN0115",
    profile: Avatar7,
    name: "Stacy Webster",
    email: "StacyWebster@rhyta.com",
    date: "07 Apr, 2020",
    status: "Active"
  },
  {
    id: "#MN0114",
    name: "Amy McDonald",
    email: "AmyMcDonald@rhyta.com",
    date: "05 Apr, 2020",
    status: "Active"
  },
  {
    id: "#MN0113",
    name: "Terry Brown",
    email: "TerryBrown@rhyta.com",
    date: "02 Apr, 2020",
    status: "Active"
  },
  {
    id: "#MN0112",
    profile: Avatar8,
    name: "Crissy Holland",
    email: "CrissyHolland@rhyta.com",
    date: "23 Mar, 2020",
    status: "Deactive"
  }
];

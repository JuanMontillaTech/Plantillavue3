<script>
/**
 * Cards component
 */
export default {};
</script>

<template>
  <div>
    <BRow>
      <BCol lg="6" cols="xl-3">
        <BCard img-src="/images/small/img-1.jpg" img-alt="Card image" img-top>
          <BCardTitle>
            <BCardTitle>Card title</BCardTitle>
          </BCardTitle>
          <BCardText>
            Some quick example text to build on the card title and make up the
            bulk of the card's content.
          </BCardText>
          <BButton href="#" variant="primary">Button</BButton>
        </BCard>
      </BCol>

      <BCol lg="6" cols="xl-3">
        <BCard no-body img-src="/images/small/img-2.jpg" img-alt="Card image" img-top>
          <BCardBody>
            <BCardTitle>Card title</BCardTitle>
            <BCardText>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </BCardText>
          </BCardBody>
          <ul class="list-group list-group-flush">
            <li class="list-group-item">Cras justo odio</li>
            <li class="list-group-item">Dapibus ac facilisis in</li>
          </ul>
          <BCardBody>
            <a href="#" class="card-link text-custom">Card link</a>
            <a href="#" class="card-link text-custom">Another link</a>
          </BCardBody>
        </BCard>
      </BCol>

      <BCol lg="6" cols="xl-3">
        <BCard img-src="/images/small/img-3.jpg" img-alt="Card image" img-top>
          <BCardText>
            Some quick example text to build on the card title and make up the
            bulk of the card's content.
          </BCardText>
        </BCard>
      </BCol>

      <BCol lg="6" cols="xl-3">
        <BCard no-body>
          <BCardBody>
            <BCardTitle>Card title</BCardTitle>
            <BCardSubTitle>
              <h6>Support card subtitle</h6>
            </BCardSubTitle>
          </BCardBody>
          <img src="/images/small/img-4.jpg" class="img-fluid" />
          <BCardBody>
            <BCardText>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </BCardText>
            <a href="#" class="card-link text-custom">Card link</a>
            <a href="#" class="card-link text-custom">Another link</a>
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>

    <BRow>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle>Special title treatment</BCardTitle>
            <BCardText>
              With supporting text below as a natural lead-in to additional
              content.
            </BCardText>
            <div class="d-grid">
              <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
          </BCardBody>
        </BCard>
      </BCol>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle>Special title treatment</BCardTitle>
            <BCardText>
              With supporting text below as a natural lead-in to additional
              content.
            </BCardText>
            <div class="d-grid">
              <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>

    <BRow>
      <BCol lg="4">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mt-0">Special title treatment</BCardTitle>
            <p class="card-text">
              With supporting text below as a natural lead-in to additional
              content.
            </p>
            <div class="d-grid">
              <a href="#" class="btn btn-primary waves-effect waves-light">Go somewhere</a>
            </div>
          </BCardBody>
        </BCard>
      </BCol>

      <BCol lg="4">
        <BCard no-body class="text-center">
          <BCardBody>
            <BCardTitle class="mt-0">Special title treatment</BCardTitle>
            <p class="card-text">
              With supporting text below as a natural lead-in to additional
              content.
            </p>
            <div class="d-grid">
              <a href="#" class="btn btn-primary waves-effect waves-light">Go somewhere</a>
            </div>
          </BCardBody>
        </BCard>
      </BCol>

      <BCol lg="4">
        <div class="card card-body text-right">
          <BCardTitle class="mt-0">Special title treatment</BCardTitle>
          <p class="card-text">
            With supporting text below as a natural lead-in to additional
            content.
          </p>
          <a href="#" class="btn btn-primary waves-effect waves-light">Go somewhere</a>
        </div>
      </BCol>
    </BRow>
    <BRow>
      <BCol md="4">
        <BCard no-body>
          <BCardHeader>
            <h5 class="mb-0">Featured</h5>
          </BCardHeader>
          <BCardBody>
            <BCardTitle>
              <h5 class="card-title">Special title treatment</h5>
            </BCardTitle>
            <BCardText>
              With supporting text below as a natural lead-in to additional
              content.
            </BCardText>
            <BButton href="#" variant="primary">Go somewhere</BButton>
          </BCardBody>
        </BCard>
      </BCol>
      <BCol md="4">
        <BCard header="Quote">
          <BCardText>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer
            posuere erat a ante.
          </BCardText>
          <footer>
            Someone famous in
            <cite title="Source Title">Source Title</cite>
          </footer>
        </BCard>
      </BCol>
      <BCol md="4">
        <BCard header="Featured" footer="2 days ago">
          <BCardText>
            <BCardTitle>Special title treatment</BCardTitle>
            <p class="card-text">
              With supporting text below as a natural lead-in to additional
              content.
            </p>
            <a href="#" class="btn btn-primary">Go somewhere</a>
          </BCardText>
        </BCard>
      </BCol>
    </BRow>

    <BRow>
      <BCol md="4">
        <BCard img-src="/images/small/img-5.jpg" img-alt="Card image" img-top>
          <BCardTitle>Card title</BCardTitle>
          <BCardText>
            <p>
              This is a wider card with supporting text below as a natural
              lead-in to additional content. This content is a little bit
              longer.
            </p>
            <p>
              <small class="text-muted">Last updated 3 mins ago</small>
            </p>
          </BCardText>
        </BCard>
      </BCol>
      <BCol md="4">
        <BCard img-src="/images/small/img-7.jpg" img-alt="Card image" img-bottom>
          <BCardTitle>Card title</BCardTitle>
          <BCardText>
            <p>
              This is a wider card with supporting text below as a natural
              lead-in to additional content. This content is a little bit
              longer.
            </p>
            <p>
              <small class="text-muted">Last updated 3 mins ago</small>
            </p>
          </BCardText>
        </BCard>
      </BCol>
      <BCol md="4">
        <BCard overlay img-src="/images/small/img-6.jpg" img-alt="Card Image" text-variant="white">
          <BCardTitle>
            <h5 class="text-white">Card title</h5>
          </BCardTitle>
          <BCardText>
            <p>
              This is a wider card with supporting text below as a natural
              lead-in to additional content. This content is a little bit
              longer.
            </p>
            <p>
              <small class="text-white">Last updated 3 mins ago</small>
            </p>
          </BCardText>
        </BCard>
      </BCol>
    </BRow>

    <BRow>
      <BCol lg="6">
        <BCard no-body>
          <BRow no-gutters class="align-items-center">
            <BCol md="4">
              <BCardImg src="/images/small/img-2.jpg" class="rounded-0"></BCardImg>
            </BCol>
            <BCol md="8">
              <BCardBody title="Card title">
                <BCardText>
                  This is a wider card with supporting text below as a natural
                  lead-in to additional content.
                </BCardText>
                <p class="card-text">
                  <small class="text-muted">Last updated 3 mins ago</small>
                </p>
              </BCardBody>
            </BCol>
          </BRow>
        </BCard>
      </BCol>
      <BCol lg="6">
        <BCard no-body>
          <BRow no-gutters class="align-items-center">
            <BCol md="8">
              <BCardBody title="Card title">
                <BCardText>
                  This is a wider card with supporting text below as a natural
                  lead-in to additional content.
                </BCardText>
                <p class="card-text">
                  <small class="text-muted">Last updated 3 mins ago</small>
                </p>
              </BCardBody>
            </BCol>
            <BCol md="4">
              <BCardImg src="/images/small/img-3.jpg" class="rounded-0"></BCardImg>
            </BCol>
          </BRow>
        </BCard>
      </BCol>
    </BRow>

    <BRow>
      <BCol md="4">
        <BCard bg-variant="primary" class="text-white-50">
          <h5 class="mt-0 mb-4 text-white">
            <i class="mdi mdi-bullseye-arrow me-3"></i> Primary Card
          </h5>
          <p class="card-text">
            Some quick example text to build on the card title and make up the
            bulk of the card's content.
          </p>
        </BCard>
      </BCol>
      <BCol md="4">
        <BCard bg-variant="success" class="text-white-50">
          <h5 class="mt-0 mb-4 text-white">
            <i class="mdi mdi-check-all me-3"></i> Success Card
          </h5>
          <p class="card-text">
            Some quick example text to build on the card title and make up the
            bulk of the card's content.
          </p>
        </BCard>
      </BCol>
      <BCol md="4">
        <BCard bg-variant="info" class="text-white-50">
          <h5 class="mt-0 mb-4 text-white">
            <i class="mdi mdi-alert-circle-outline me-3"></i> Info Card
          </h5>
          <p class="card-text">
            Some quick example text to build on the card title and make up the
            bulk of the card's content.
          </p>
        </BCard>
      </BCol>
    </BRow>

    <BRow>
      <BCol md="4">
        <BCard bg-variant="warning" class="text-white-50">
          <h5 class="mt-0 mb-4 text-white">
            <i class="mdi mdi-alert-outline me-3"></i> Warning Card
          </h5>
          <p class="card-text">
            Some quick example text to build on the card title and make up the
            bulk of the card's content.
          </p>
        </BCard>
      </BCol>
      <BCol md="4">
        <BCard bg-variant="danger" class="text-white-50">
          <h5 class="mt-0 mb-4 text-white">
            <i class="mdi mdi-block-helper me-3"></i> Danger Card
          </h5>
          <p class="card-text">
            Some quick example text to build on the card title and make up the
            bulk of the card's content.
          </p>
        </BCard>
      </BCol>
      <BCol md="4">
        <BCard bg-variant="dark" class="text-white-50">
          <h5 class="mt-0 mb-4 text-white">
            <i class="mdi mdi-alert-circle-outline me-3"></i> Dark Card
          </h5>
          <p class="card-text">
            Some quick example text to build on the card title and make up the
            bulk of the card's content.
          </p>
        </BCard>
      </BCol>
    </BRow>

    <BRow>
      <BCol lg="4">
        <BCard header-class="bg-transparent border-primary" class="border border-primary">
          <template v-slot:header>
            <h5 class="my-0 text-primary">
              <i class="mdi mdi-bullseye-arrow me-3"></i>Primary outline Card
            </h5>
          </template>
          <BCardTitle tags="h5" class="mt-0">card title</BCardTitle>
          <p class="card-text">
            Some quick example text to build on the card title and make up the
            bulk of the card's content.
          </p>
        </BCard>
      </BCol>
      <BCol lg="4">
        <BCard header-class="bg-transparent border-danger" class="border border-danger">
          <template v-slot:header>
            <h5 class="my-0 text-danger">
              <i class="mdi mdi-block-helper me-3"></i>Danger outline Card
            </h5>
          </template>
          <BCardTitle tags="h5" class="mt-0">card title</BCardTitle>
          <p class="card-text">
            Some quick example text to build on the card title and make up the
            bulk of the card's content.
          </p>
        </BCard>
      </BCol>
      <BCol lg="4">
        <BCard header-class="bg-transparent border-success" class="border border-success">
          <template v-slot:header>
            <h5 class="my-0 text-success">
              <i class="mdi mdi-block-helper me-3"></i>Success outline Card
            </h5>
          </template>
          <BCardTitle tags="h5" class="mt-0">card title</BCardTitle>
          <p class="card-text">
            Some quick example text to build on the card title and make up the
            bulk of the card's content.
          </p>
        </BCard>
      </BCol>
    </BRow>

    <BRow>
      <BCol cols="12">
        <h4 class="my-3">Card groups</h4>
        <div class="card-deck-wrapper">
          <div class="card-group">
            <BCard no-body class="mb-4">
              <img class="card-img-top img-fluid" src="/images/small/img-4.jpg" alt="Card image cap" />
              <BCardBody>
                <BCardTitle class="mt-0">Card title</BCardTitle>
                <p class="card-text">
                  This is a longer card with supporting text below as a natural
                  lead-in to additional content. This content is a little bit
                  longer.
                </p>
                <p class="card-text">
                  <small class="text-muted">Last updated 3 mins ago</small>
                </p>
              </BCardBody>
            </BCard>
            <BCard no-body class="mb-4">
              <img class="card-img-top img-fluid" src="/images/small/img-5.jpg" alt="Card image cap" />
              <BCardBody>
                <BCardTitle class="mt-0">Card title</BCardTitle>
                <p class="card-text">
                  This card has supporting text below as a natural lead-in to
                  additional content.
                </p>
                <p class="card-text">
                  <small class="text-muted">Last updated 3 mins ago</small>
                </p>
              </BCardBody>
            </BCard>
            <BCard no-body class="mb-4">
              <img class="card-img-top img-fluid" src="/images/small/img-6.jpg" alt="Card image cap" />
              <BCardBody>
                <BCardTitle class="mt-0">Card title</BCardTitle>
                <p class="card-text">
                  This is a wider card with supporting text below as a natural
                  lead-in to additional content. This card has even longer
                  content than the first to show that equal height action.
                </p>
                <p class="card-text">
                  <small class="text-muted">Last updated 3 mins ago</small>
                </p>
              </BCardBody>
            </BCard>
          </div>
        </div>
      </BCol>
    </BRow>
  </div>
</template>

<script>
import SimpleAlert from "~/components/uiComponents/alert/components/SimpleAlert.vue";
import DismissibleAlert from "~/components/uiComponents/alert/components/DismissibleAlert.vue";

/**
 * Alerts component
 */
export default {
  data() {
    return {
      dismissSecs: 5000,
      dismissCountDown: 0,
      countdown: 0
    };
  },
  components: {
    SimpleAlert,
    DismissibleAlert
  },
  methods: {
    showAlert() {
      this.dismissCountDown = this.dismissSecs;
    },
    onCloseCountDown(event) {
      this.dismissCountDown = event;
      this.countdown = event;
    }
  }
};
</script>

<template>
  <ClientOnly>
    <BRow>
      <BCol cols="xl-6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle>Default Alerts</BCardTitle>
            <p class="card-title-desc">
              Alerts are available for any length of text, as well as an
              optional dismiss button. For proper styling, use one of the four
              required contextual classes (e.g.,
              <code class="highlighter-rouge">success</code>).
            </p>

            <div class="">
              <SimpleAlert classes="alert-primary">
                A simple Primary alert —check it out!
              </SimpleAlert>
              <SimpleAlert classes="alert-secondary">
                How are you! A simple secondary alert —check it out!
              </SimpleAlert>
              <SimpleAlert classes="alert-success">
                Yey! Everything worked! A simple success alert —check it out!
              </SimpleAlert>
              <SimpleAlert classes="alert-danger">
                Something is very wrong! A simple danger alert —check it out!
              </SimpleAlert>
              <SimpleAlert classes="alert-warning">
                Uh oh, something went wrong A simple warning alert —check it
                out!
              </SimpleAlert>
              <SimpleAlert classes="alert-info mb-0">
                Don't forget' it ! A simple info alert —check it out!
              </SimpleAlert>
            </div>
          </BCardBody>
        </BCard>
      </BCol>

      <BCol cols="xl-6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle>Link color</BCardTitle>
            <p class="card-title-desc">
              Use the <code class="highlighter-rouge">.alert-link</code> utility
              class to quickly provide matching colored links within any alert.
            </p>

            <div class="">
              <SimpleAlert class="alert-primary">
                A simple primary alert with<a href="#" class="alert-link">an example link</a>. Give it a click if you like.
              </SimpleAlert>
              <SimpleAlert class="alert-secondary">
                A simple secondary alert with<a href="#" class="alert-link">an example link</a>. Give it a click if you like.
              </SimpleAlert>

              <SimpleAlert class="alert alert-success">
                A simple success alert with<a href="#" class="alert-link">an example link</a>. Give it a click if you like.
              </SimpleAlert>
              <SimpleAlert class="alert alert-danger">
                A simple danger alert with<a href="#" class="alert-link">an example link</a>. Give it a click if you like.
              </SimpleAlert>
              <SimpleAlert class="alert alert-warning">
                A simple warning alert with<a href="#" class="alert-link">an example link</a>. Give it a click if you like.
              </SimpleAlert>
              <SimpleAlert class="alert alert-info mb-0">
                A simple warning alert with<a href="#" class="alert-link">an example link</a>. Give it a click if you like.
              </SimpleAlert>
            </div>
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>

    <BRow>
      <BCol cols="xl-6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle>Dismissing</BCardTitle>
            <p class="card-title-desc">
              Add a dismiss button and the
              <code>.alert-dismissible</code> class, which adds extra padding to
              the right of the alert and positions the
              <code>.close</code> button.
            </p>

            <div class="">
              <DismissibleAlert variant="primary">
                A simple Dismissible primary Alert — check it out!
              </DismissibleAlert>
              <DismissibleAlert variant="secondary">
                A simple secondary alert—check it out!
              </DismissibleAlert>
              <DismissibleAlert variant="success">
                A simple success alert—check it out!
              </DismissibleAlert>
              <DismissibleAlert variant="danger">
                A simple danger alert—check it out!
              </DismissibleAlert>
              <DismissibleAlert variant="warning" role="alert">
                A simple warning alert—check it out!
              </DismissibleAlert>
              <DismissibleAlert variant="info" classes="mb-0">
                A simple info alert—check it out!
              </DismissibleAlert>
            </div>
          </BCardBody>
        </BCard>
      </BCol>

      <BCol cols="xl-6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">With Icon</BCardTitle>

            <div class="">
              <DismissibleAlert variant="primary">
                <i class="mdi mdi-bullseye-arrow me-2"></i> A simple primary
                alert—check it out!
              </DismissibleAlert>

              <DismissibleAlert variant="secondary">
                <i class="mdi mdi-grease-pencil me-2"></i> A simple secondary
                alert—check it out!
              </DismissibleAlert>

              <DismissibleAlert variant="success">
                <i class="mdi mdi-check-all me-2"></i> A simple success
                alert—check it out!
              </DismissibleAlert>
              <DismissibleAlert variant="danger">
                <i class="mdi mdi-block-helper me-2"></i> A simple danger
                alert—check it out!
              </DismissibleAlert>
              <DismissibleAlert variant="warning">
                <i class="mdi mdi-alert-outline me-2"></i> A simple warning
                alert—check it out!
              </DismissibleAlert>
              <DismissibleAlert variant="info">
                <i class="mdi mdi-alert-circle-outline me-2"></i> A simple info
                alert—check it out!
              </DismissibleAlert>
            </div>
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>

    <BRow>
      <BCol cols="xl-6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle>Alert Border Examples</BCardTitle>
            <p class="card-title-desc">
              Add <code>alert-border</code> class for Alert Border Examples and
              add <code>alert-border-*</code> color classes for border color
              variant
            </p>

            <div class="">
              <DismissibleAlert classes="alert-border border-primary" variant="border-primary">
                <i class="uil uil-user-circle text-primary font-size-16 me-2" />
                A simple border primary alert
              </DismissibleAlert>
              <DismissibleAlert classes="alert-border border-secondary" variant="border-secondary">
                <i class="uil uil-pen font-size-16 text-secondary me-2"></i>
                A simple border secondary alert
              </DismissibleAlert>
              <DismissibleAlert classes="alert-border border-success" variant="border-success">
                <i class="uil uil-check font-size-16 text-success me-2"></i>
                A simple border success alert
              </DismissibleAlert>
              <DismissibleAlert classes="alert-border border-danger" variant="border-danger">
                <i class="uil uil-exclamation-octagon font-size-16 text-danger me-2"></i>
                A simple border danger alert
              </DismissibleAlert>
              <DismissibleAlert classes="alert-border border-warning" variant="border-warning">
                <i class="uil uil-exclamation-triangle font-size-16 text-warning me-2"></i>
                A simple border warning alert
              </DismissibleAlert>
              <DismissibleAlert classes="alert-border border-info" variant="border-info mb-0">
                <i class="uil uil-question-circle font-size-16 text-info me-2"></i>
                A simple border info alert
              </DismissibleAlert>
            </div>
          </BCardBody>
        </BCard>
      </BCol>

      <BCol cols="xl-6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-0">Alert Examples</BCardTitle>

            <BRow>
              <BCol sm="6">
                <DismissibleAlert variant="success" classes="text-center mt-4 px-4 mb-0">
                  <i class="uil uil-check-circle d-block display-4 mt-2 mb-3 text-success" />
                  <h5 class="text-success">Success</h5>
                  <p>A simple success alert</p>
                </DismissibleAlert>
              </BCol>

              <BCol sm="6">
                <DismissibleAlert variant="danger" class="text-center mt-4 px-4 mb-0">
                  <i class="uil uil-exclamation-octagon d-block display-4 mt-2 mb-3 text-danger"></i>
                  <h5 class="text-danger">Error</h5>
                  <p>A simple danger alert</p>
                </DismissibleAlert>
              </BCol>

              <BCol sm="6">
                <DismissibleAlert dismissible show variant="border-warning" classes="text-center mt-4 px-4 mb-0 border-warning">
                  <i class="uil uil-exclamation-triangle d-block display-4 mt-2 mb-3 text-warning"></i>
                  <h5 class="text-warning">Error</h5>
                  <p>A simple warning alert</p>
                </DismissibleAlert>
              </BCol>

              <BCol sm="6">
                <DismissibleAlert variant="border-info" classes="text-center mt-4 px-4 mb-0 border-info">
                  <i class="uil uil-question-circle d-block display-4 mt-2 mb-3 text-info"></i>
                  <h5 class="text-info">Info</h5>
                  <p>A simple info alert</p>
                </DismissibleAlert>
              </BCol>
            </BRow>
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>

    <BRow>
      <BCol cols="xl-6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle>Live Example</BCardTitle>
            <p class="card-title-desc">
              Click the button below to show an alert (hidden with inline styles
              to start), then dismiss (and destroy) it with the built-in close
              button.
            </p>
            <ClientOnly>
              <BAlert v-model="dismissCountDown" dismissible variant="warning" @close-countdown="onCloseCountDown">
                <p>
                  This alert will dismiss after
                  {{ countdown / 1000 }} seconds...
                </p>
                <BProgress variant="warning" :max="dismissCountDown" :value="countdown" height="4px" />
              </BAlert>
            </ClientOnly>
            <BButton @click="showAlert" variant="primary" class="m-1">
              Show alert with count-down timer
            </BButton>
          </BCardBody>
        </BCard>
      </BCol>

      <BCol cols="xl-6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle>Additional content</BCardTitle>
            <p class="card-title-desc">
              Alerts can also contain additional HTML elements like headings,
              paragraphs and dividers.
            </p>

            <SimpleAlert classes="alert-success">
              <h4 class="alert-heading">Well done!</h4>
              <p>
                Aww yeah, you successfully read this important alert message.
                This example text is going to run a bit longer so that you can
                see how spacing within an alert works with this kind of content.
              </p>
              <hr />
              <p class="mb-0">
                Whenever you need to, be sure to use margin utilities to keep
                things nice and tidy.
              </p>
            </SimpleAlert>
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>
  </ClientOnly>
</template>

<template>
  <div>
    <BRow>
      <BCol cols="12">
        <BCard no-body>
          <BCardBody>
            <BCardTitle>Modals Examples</BCardTitle>
            <p class="card-title-desc">
              Modals are streamlined, but flexible dialog prompts powered by
              JavaScript. They support a number of use cases from user
              notification to completely custom content and feature a handful of
              helpful subcomponents, sizes, and more.
            </p>
            <div class="modal bs-example-modal" tabindex="-1" role="dialog">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title mt-0">Modal title</h5>

                    <BButton class="close" data-dismiss="modal" variant="light" aria-label="Close">
                      <i class="fa fa-times"></i>
                    </BButton>
                  </div>
                  <div class="modal-body">
                    <p>One fine body&hellip;</p>
                  </div>
                  <div class="modal-footer">
                    <BButton variant="primary"> Save changes </BButton>
                    <BButton variant="light" data-dismiss="modal">
                      Close
                    </BButton>
                  </div>
                </div>
              </div>
            </div>
            <BRow>
              <BCol cols="xl-6" md="6">
                <div>
                  <BCardTitle>Default Modal</BCardTitle>
                  <p class="card-title-desc">
                    Toggle a working modal demo by clicking the button below. It
                    will slide down and fade in from the top of the page.
                  </p>
                  <BButton variant="primary" v-b-modal.modal-standard>
                    Standard modal
                  </BButton>
                  <BModal id="modal-standard" title="Modal Heading" title-class="font-18" cancel-variant="light">
                    <h5>Overflowing text to show scroll behavior</h5>
                    <p>
                      Cras mattis consectetur purus sit amet fermentum. Cras
                      justo odio, dapibus ac facilisis in, egestas eget quam.
                      Morbi leo risus, porta ac consectetur ac, vestibulum at
                      eros.
                    </p>
                    <p>
                      Praesent commodo cursus magna, vel scelerisque nisl
                      consectetur et. Vivamus sagittis lacus vel augue laoreet
                      rutrum faucibus dolor auctor.
                    </p>
                    <p>
                      Aenean lacinia bibendum nulla sed consectetur. Praesent
                      commodo cursus magna, vel scelerisque nisl consectetur et.
                      Donec sed odio dui. Donec ullamcorper nulla non metus
                      auctor fringilla.
                    </p>
                    <p>
                      Cras mattis consectetur purus sit amet fermentum. Cras
                      justo odio, dapibus ac facilisis in, egestas eget quam.
                      Morbi leo risus, porta ac consectetur ac, vestibulum at
                      eros.
                    </p>
                    <p>
                      Praesent commodo cursus magna, vel scelerisque nisl
                      consectetur et. Vivamus sagittis lacus vel augue laoreet
                      rutrum faucibus dolor auctor.
                    </p>
                    <p>
                      Aenean lacinia bibendum nulla sed consectetur. Praesent
                      commodo cursus magna, vel scelerisque nisl consectetur et.
                      Donec sed odio dui. Donec ullamcorper nulla non metus
                      auctor fringilla.
                    </p>
                    <p>
                      Cras mattis consectetur purus sit amet fermentum. Cras
                      justo odio, dapibus ac facilisis in, egestas eget quam.
                      Morbi leo risus, porta ac consectetur ac, vestibulum at
                      eros.
                    </p>
                  </BModal>
                </div>
              </BCol>
              <BCol cols="xl-6" md="6" class="mt-3 mt-md-0">
                <div>
                  <BCardTitle>Optional sizes</BCardTitle>
                  <p class="card-title-desc">
                    Modals have three optional sizes, available via modifier
                    classes to be placed on a <code>.modal-dialog</code>.
                  </p>
                  <div class="button-items">
                    <BButton variant="primary" class="waves-effect waves-light my-2 my-md-0" v-b-modal.modal-xl>
                      Extra large modal
                    </BButton>
                    <BModal id="modal-xl" size="xl" title="Extra large modal" title-class="font-18" hide-footer>
                      <p>
                        Cras mattis consectetur purus sit amet fermentum. Cras
                        justo odio, dapibus ac facilisis in, egestas eget quam.
                        Morbi leo risus, porta ac consectetur ac, vestibulum at
                        eros.
                      </p>
                      <p>
                        Praesent commodo cursus magna, vel scelerisque nisl
                        consectetur et. Vivamus sagittis lacus vel augue laoreet
                        rutrum faucibus dolor auctor.
                      </p>
                      <p class="mb-0">
                        Aenean lacinia bibendum nulla sed consectetur. Praesent
                        commodo cursus magna, vel scelerisque nisl consectetur
                        et. Donec sed odio dui. Donec ullamcorper nulla non
                        metus auctor fringilla.
                      </p>
                    </BModal>
                    <BButton variant="success" class="waves-effect waves-light m-1" v-b-modal.modal-lg>
                      Large modal
                    </BButton>
                    <BModal id="modal-lg" size="lg" title="Large modal" title-class="font-18" hide-footer>
                      <p>
                        Cras mattis consectetur purus sit amet fermentum. Cras
                        justo odio, dapibus ac facilisis in, egestas eget quam.
                        Morbi leo risus, porta ac consectetur ac, vestibulum at
                        eros.
                      </p>
                      <p>
                        Praesent commodo cursus magna, vel scelerisque nisl
                        consectetur et. Vivamus sagittis lacus vel augue laoreet
                        rutrum faucibus dolor auctor.
                      </p>
                      <p class="mb-0">
                        Aenean lacinia bibendum nulla sed consectetur. Praesent
                        commodo cursus magna, vel scelerisque nisl consectetur
                        et. Donec sed odio dui. Donec ullamcorper nulla non
                        metus auctor fringilla.
                      </p>
                    </BModal>
                    <BButton variant="danger" class="waves-effect waves-light" v-b-modal.modal-sm>
                      Small modal
                    </BButton>
                    <BModal id="modal-sm" size="sm" title="Small modal" title-class="font-18" hide-footer>
                      <p>
                        Cras mattis consectetur purus sit amet fermentum. Cras
                        justo odio, dapibus ac facilisis in, egestas eget quam.
                        Morbi leo risus, porta ac consectetur ac, vestibulum at
                        eros.
                      </p>
                      <p>
                        Praesent commodo cursus magna, vel scelerisque nisl
                        consectetur et. Vivamus sagittis lacus vel augue laoreet
                        rutrum faucibus dolor auctor.
                      </p>
                      <p class="mb-0">
                        Aenean lacinia bibendum nulla sed consectetur. Praesent
                        commodo cursus magna, vel scelerisque nisl consectetur
                        et. Donec sed odio dui. Donec ullamcorper nulla non
                        metus auctor fringilla.
                      </p>
                    </BModal>
                  </div>
                </div>
              </BCol>
            </BRow>

            <div class="mt-4">
              <BRow>
                <BCol cols="xl-4" md="6">
                  <div class="mt-4">
                    <BCardTitle tags="h5">Vertically centered</BCardTitle>
                    <p class="card-title-desc">
                      Add <code>.modal-dialog-centered</code> to
                      <code>.modal-dialog</code> to vertically center the modal.
                    </p>
                  </div>
                  <BButton v-b-modal.modal-center variant="primary" class="waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-center">
                    Center modal
                  </BButton>
                  <BModal id="modal-center" centered title="Center modal" title-class="font-18" hide-footer>
                    <p>
                      Cras mattis consectetur purus sit amet fermentum. Cras
                      justo odio, dapibus ac facilisis in, egestas eget quam.
                      Morbi leo risus, porta ac consectetur ac, vestibulum at
                      eros.
                    </p>
                    <p>
                      Praesent commodo cursus magna, vel scelerisque nisl
                      consectetur et. Vivamus sagittis lacus vel augue laoreet
                      rutrum faucibus dolor auctor.
                    </p>
                    <p class="mb-0">
                      Aenean lacinia bibendum nulla sed consectetur. Praesent
                      commodo cursus magna, vel scelerisque nisl consectetur et.
                      Donec sed odio dui. Donec ullamcorper nulla non metus
                      auctor fringilla.
                    </p>
                  </BModal>
                </BCol>
                <BCol cols="xl-4" md="6">
                  <div class="mt-4">
                    <BCardTitle tags="h5">Scrollable modal</BCardTitle>
                    <p class="card-title-desc">
                      You can also create a scrollable modal that allows scroll
                      the modal body by adding
                      <code>.modal-dialog-scrollable</code> to
                      <code>.modal-dialog</code>.
                    </p>
                    <BButton variant="primary" v-b-modal.modal-scrollable class="waves-effect waves-light" data-toggle="modal" data-target="#exampleModalScrollable">
                      Scrollable modal
                    </BButton>
                    <BModal id="modal-scrollable" scrollable title="Scrollable Modal" title-class="font-18" cancel-variant="light">
                      <p v-for="i in 15" :key="i">
                        Cras mattis consectetur purus sit amet fermentum. Cras
                        justo odio, dapibus ac facilisis in, egestas eget quam.
                        Morbi leo risus, porta ac consectetur ac, vestibulum at
                        eros.
                      </p>
                    </BModal>
                  </div>
                </BCol>
              </BRow>
            </div>
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>
  </div>
</template>

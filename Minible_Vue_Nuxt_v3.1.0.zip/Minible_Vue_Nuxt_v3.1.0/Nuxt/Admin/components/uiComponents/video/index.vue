<script>
/**
 * Video component
 */
export default {};
</script>

<template>
  <div>
    <BRow>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle>Responsive embed video 16:9</BCardTitle>
            <p class="card-title-desc">
              Aspect ratios can be customized with modifier classes.
            </p>

            <div class="embed-responsive embed-responsive-16by9 ratio ratio-16x9">
              <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/1y_kfWUCFDQ"></iframe>
            </div>
          </BCardBody>
        </BCard>
      </BCol>

      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle>Responsive embed video 21:9</BCardTitle>
            <p class="card-title-desc">
              Aspect ratios can be customized with modifier classes.
            </p>

            <div class="embed-responsive embed-responsive-21by9 ratio ratio-21x9">
              <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/1y_kfWUCFDQ"></iframe>
            </div>
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>

    <BRow>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle>Responsive embed video 4:3</BCardTitle>
            <p class="card-title-desc">
              Aspect ratios can be customized with modifier classes.
            </p>

            <div class="embed-responsive embed-responsive-4by3 ratio ratio-4x3">
              <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/1y_kfWUCFDQ"></iframe>
            </div>
          </BCardBody>
        </BCard>
      </BCol>

      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle>Responsive embed video 1:1</BCardTitle>
            <p class="card-title-desc">
              Aspect ratios can be customized with modifier classes.
            </p>

            <div class="embed-responsive embed-responsive-1by1 ratio ratio-1x1">
              <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/1y_kfWUCFDQ"></iframe>
            </div>
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>
  </div>
</template>

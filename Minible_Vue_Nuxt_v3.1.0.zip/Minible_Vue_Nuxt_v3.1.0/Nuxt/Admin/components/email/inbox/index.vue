<script>
import Toolbar from "~/components/email/components/Toolbar.vue";
import SidePanel from "~/components/email/components/SidePanel.vue";

import { emailData } from "~/components/email/utils.js";

/**
 * Email-inbox component
 */
export default {
  components: {
    Toolbar,
    SidePanel
  },
  data() {
    return {
      emailData: emailData,
      paginatedEmailData: emailData,
      // page number
      currentPage: 1,
      // default page size
      perPage: 15,
      emailIds: [],
      // start and end index
      startIndex: 1,
      endIndex: 15
    };
  },
  watch: {
    currentPage() {
      this.startIndex = (this.currentPage - 1) * this.perPage;
      this.endIndex = (this.currentPage - 1) * this.perPage + this.perPage;

      this.paginatedEmailData = this.emailData.slice(
        this.startIndex,
        this.endIndex
      );
    }
  },
  computed: {
    rows() {
      return this.emailData.length;
    }
  },
  created() {
    this.startIndex = 0;
    this.endIndex = this.perPage;

    this.paginatedEmailData = this.emailData.slice(
      this.startIndex,
      this.endIndex
    );
  }
};
</script>

<template>
  <div>
    <BRow>
      <BCol cols="12">
        <SidePanel />
        <div class="email-rightbar mb-3">
          <BCard no-body>
            <Toolbar />

            <div class="mt-3">
              <ul class="message-list">
                <li v-for="(email, index) in paginatedEmailData" :key="index" :class="{ unread: email.unread === true }" :to="`/email/reademail/${email.id}`">
                  <div class="col-mail col-mail-1">
                    <div class="checkbox-wrapper-mail">
                      <input :id="`chk-${index}`" type="checkbox" />
                      <label :for="`chk-${index}`"></label>
                    </div>
                    <span :class="`star-toggle far fa-star text-${email.text}`"></span>
                    <a class="title">
                      <NuxtLink tag="a" :to="'/email/reademail/' + email.id" class="subject">{{ email.title }}</NuxtLink>
                    </a>
                  </div>
                  <div class="col-mail col-mail-2">
                    <NuxtLink tag="a" :to="'/email/reademail/' + email.id" class="subject">{{ email.subject }}</NuxtLink>

                    <div class="date">{{ email.date }}</div>
                  </div>
                </li>
              </ul>
            </div>
          </BCard>
          <BRow class="justify-content-md-between align-items-md-center">
            <BCol cols="xl-7">
              Showing {{ startIndex }} - {{ endIndex }} of {{ rows }}
            </BCol>
            <BCol cols="xl-5">
              <div class="text-md-end float-xl-end mt-2 pagination-rounded">
                <BPagination v-model="currentPage" :total-rows="rows" :per-page="perPage" />
              </div>
            </BCol>
          </BRow>
        </div>
      </BCol>
    </BRow>
  </div>
</template>

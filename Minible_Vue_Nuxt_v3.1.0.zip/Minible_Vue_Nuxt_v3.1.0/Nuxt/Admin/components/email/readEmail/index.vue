<script>
import Toolbar from "~/components/email/components/Toolbar.vue";
import SidePanel from "~/components/email/components/SidePanel.vue";
import { emailData } from "~/components/email/utils.js";
import { BCardImg } from "bootstrap-vue-next";

/**
 * Read-email component
 */
export default {
  props: {
    emailId: {
      type: Number,
      required: true
    }
  },
  components: {
    Toolbar,
    SidePanel,
    BCardImg
  },
  computed: {
    emailRead() {
      return emailData.find((user) => user.id === this.$props.emailId);
    }
  }
};
</script>

<template>
  <div>
    <BRow>
      <BCol cols="12">
        <SidePanel />
        <div class="email-rightbar mb-3">
          <BCard no-body>
            <Toolbar />
            <BCardBody>
              <div class="media mb-4 d-flex">
                <img class="d-flex me-3 rounded-circle avatar-sm" src="/images/users/avatar-2.jpg" alt="Generic placeholder image" />
                <div class="media-body">
                  <h5 class="font-size-14 mt-1">Humberto D. Champion</h5>
                  <small class="text-muted">support@domain.com</small>
                </div>
              </div>

              <h4 class="mt-0 font-size-16">{{ emailRead.title }}</h4>

              <p>Dear Lorem Ipsum,</p>
              <p>{{ emailRead.subject }}</p>
              <p>
                Sed elementum turpis eu lorem interdum, sed porttitor eros
                commodo. Nam eu venenatis tortor, id lacinia diam. Sed aliquam
                in dui et porta. Sed bibendum orci non tincidunt ultrices.
                Vivamus fringilla, mi lacinia dapibus condimentum, ipsum urna
                lacinia lacus, vel tincidunt mi nibh sit amet lorem.
              </p>
              <p>Sincerly,</p>
              <hr />
              <BRow>
                <BCol cols="6" xl="2">
                  <BCard no-body class="border shadow-none" img-src="/images/small/img-3.jpg" img-alt="Card image cap" img-top>
                    <div class="py-2 text-center">
                      <a href class="fw-medium">Download</a>
                    </div>
                  </BCard>
                </BCol>
                <BCol cols="6" class="col-xl-2">
                  <BCard no-body class="border shadow-none" img-src="/images/small/img-4.jpg" img-alt="Card image cap" img-top>
                    <div class="py-2 text-center">
                      <a href class="fw-medium">Download</a>
                    </div>
                  </BCard>
                </BCol>
              </BRow>
              <a href="#" class="btn btn-secondary waves-effect mt-4">
                <i class="mdi mdi-reply"></i> Reply
              </a>
            </BCardBody>
          </BCard>
        </div>
      </BCol>
    </BRow>
  </div>
</template>

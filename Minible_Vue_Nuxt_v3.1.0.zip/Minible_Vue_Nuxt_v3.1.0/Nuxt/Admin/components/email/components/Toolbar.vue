<template>
  <div class="btn-toolbar p-3">
    <BButtonGroup class="me-2 mb-2 mb-sm-0">
      <BButton variant="primary">
        <i class="fa fa-inbox"></i>
      </BButton>
      <BButton variant="primary">
        <i class="fa fa-exclamation-circle"></i>
      </BButton>
      <BButton variant="primary">
        <i class="far fa-trash-alt"></i>
      </BButton>
    </BButtonGroup>

    <BDropdown class="me-2 mb-2 mb-sm-0" variant="primary">
      <template #button-content>
        <i class="fa fa-folder"></i>
        <i class="mdi mdi-chevron-down ms-1"></i>
      </template>

      <BDropdownItem href="#">Updates</BDropdownItem>
      <BDropdownItem href="#">Social</BDropdownItem>
      <BDropdownItem href="#">Team Manage</BDropdownItem>
    </BDropdown>

    <BDropdown class="me-2 mb-2 mb-sm-0" variant="primary">
      <template #button-content>
        <i class="fa fa-tag"></i>
        <i class="mdi mdi-chevron-down ms-1"></i>
      </template>
      <BDropdownItem href="#">Updates</BDropdownItem>
      <BDropdownItem href="#">Social</BDropdownItem>
      <BDropdownItem href="#">Team Manage</BDropdownItem>
    </BDropdown>

    <BDropdown class="me-2 mb-2 mb-sm-0" variant="primary">
      <template #button-content>
        More
        <i class="mdi mdi-dots-vertical ms-2"></i>
      </template>
      <BDropdownItem href="#">Mark as Unread</BDropdownItem>
      <BDropdownItem href="#">Add to Tasks</BDropdownItem>
      <BDropdownItem href="#">Add Star</BDropdownItem>
      <BDropdownItem href="#">Mute</BDropdownItem>
    </BDropdown>
  </div>
</template>

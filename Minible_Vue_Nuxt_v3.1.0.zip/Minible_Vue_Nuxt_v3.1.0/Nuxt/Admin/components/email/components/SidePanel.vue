<script>
/**
 * Side-panel component
 */
import CKEditor from "~/components/common/CKEditor.vue";

export default {
  components: {
    CKEditor
  },
  data() {
    return {
      showModal: false
    };
  }
};
</script>

<template>
  <div class="email-leftbar card">
    <BButton variant="danger" @click="showModal = true">Compose</BButton>
    <div class="mail-list mt-4">
      <nuxt-link to="/email/inbox" class="active">
        <i class="mdi mdi-email-outline me-2"></i> Inbox
        <span class="ms-1 float-end">(18)</span>
      </nuxt-link>

      <nuxt-link to="/email/inbox">
        <i class="mdi mdi-star-outline me-2"></i>Starred
      </nuxt-link>
      <nuxt-link to="/email/inbox">
        <i class="mdi mdi-diamond-stone me-2"></i>Important
      </nuxt-link>
      <nuxt-link to="/email/inbox">
        <i class="mdi mdi-file-outline me-2"></i>Draft
      </nuxt-link>
      <nuxt-link to="/email/inbox">
        <i class="mdi mdi-email-check-outline me-2"></i>Sent Mail
      </nuxt-link>
      <nuxt-link to="/email/inbox">
        <i class="mdi mdi-trash-can-outline me-2"></i>Trash
      </nuxt-link>
    </div>

    <h6 class="mt-4">Labels</h6>

    <div class="mail-list mt-1">
      <a href="#">
        <span class="mdi mdi-arrow-right-drop-circle text-info float-end"></span>Theme Support
      </a>
      <a href="#">
        <span class="mdi mdi-arrow-right-drop-circle text-warning float-end"></span>Freelance
      </a>
      <a href="#">
        <span class="mdi mdi-arrow-right-drop-circle text-primary float-end"></span>Social
      </a>
      <a href="#">
        <span class="mdi mdi-arrow-right-drop-circle text-danger float-end"></span>Friends
      </a>
      <a href="#">
        <span class="mdi mdi-arrow-right-drop-circle text-success float-end"></span>Family
      </a>
    </div>

    <h6 class="mt-4">Chat</h6>

    <div class="mt-2">
      <a href="#" class="media d-flex">
        <img class="d-flex me-3 rounded-circle" src="/images/users/avatar-2.jpg" alt="Generic placeholder image" height="36" />
        <div class="media-body chat-user-box">
          <p class="user-title m-0">Scott Median</p>
          <p class="text-muted">Hello</p>
        </div>
      </a>

      <a href="#" class="media d-flex">
        <img class="d-flex me-3 rounded-circle" src="/images/users/avatar-3.jpg" alt="Generic placeholder image" height="36" />
        <div class="media-body chat-user-box">
          <p class="user-title m-0">Julian Rosa</p>
          <p class="text-muted">What about our next..</p>
        </div>
      </a>

      <a href="#" class="media d-flex">
        <img class="d-flex me-3 rounded-circle" src="/images/users/avatar-4.jpg" alt="Generic placeholder image" height="36" />
        <div class="media-body chat-user-box">
          <p class="user-title m-0">David Medina</p>
          <p class="text-muted">Yeah everything is fine</p>
        </div>
      </a>

      <a href="#" class="media d-flex">
        <img class="d-flex me-3 rounded-circle" src="/images/users/avatar-6.jpg" alt="Generic placeholder image" height="36" />
        <div class="media-body chat-user-box">
          <p class="user-title m-0">Jay Baker</p>
          <p class="text-muted">Wow that's great</p>
        </div>
      </a>
    </div>

    <BModal v-model="showModal" title="New Message" centered>
      <BForm>
        <div class="mb-3">
          <input type="email" class="form-control" placeholder="To" />
        </div>

        <div class="mb-3">
          <input type="text" class="form-control" placeholder="Subject" />
        </div>
        <div class="form-group">
          <CKEditor />
        </div>
      </BForm>
      <template v-slot:modal-footer>
        <BButton variant="secondary" @click="showModal = false">Close</BButton>
        <BButton variant="primary">
          Send
          <i class="fab fa-telegram-plane ms-1"></i>
        </BButton>
      </template>
    </BModal>
  </div>
</template>

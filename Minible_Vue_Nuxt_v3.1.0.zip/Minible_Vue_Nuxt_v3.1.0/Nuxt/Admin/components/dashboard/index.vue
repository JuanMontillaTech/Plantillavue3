<script>
import Stat from "~/components/dashboard/components/Stat.vue";
import SalesAnalytics from "~/components/dashboard/components/SalesAnalytics.vue";
import SellingProduct from "~/components/dashboard/components/SellingProduct.vue";
import TopUsers from "~/components/dashboard/components/TopUsers.vue";
import RecentActivity from "~/components/dashboard/components/RecentActivity.vue";
import SocialSource from "~/components/dashboard/components/SocialSource.vue";

export default {
  components: {
    Stat,
    SalesAnalytics,
    SellingProduct,
    TopUsers,
    RecentActivity,
    SocialSource
  }
};
</script>

<template>
  <div>
    <Stat />
    <BRow>
      <SalesAnalytics />
      <BCol cols="xl-4">
        <BCard no-body bg-variant="primary">
          <BCardBody>
            <BRow class="align-items-center">
              <BCol sm="8">
                <p class="text-white font-size-18">
                  Enhance your
                  <b>Campaign</b> for better outreach
                  <i class="mdi mdi-arrow-right"></i>
                </p>
                <div class="mt-4">
                  <a href="#" class="btn btn-success waves-effect waves-light">Upgrade Account!</a>
                </div>
              </BCol>
              <BCol sm="4">
                <div class="mt-4 mt-sm-0">
                  <img src="/images/setup-analytics-amico.svg" class="img-fluid" alt />
                </div>
              </BCol>
            </BRow>
          </BCardBody>
        </BCard>
        <SellingProduct />
      </BCol>
    </BRow>
    <BRow>
      <TopUsers />
      <RecentActivity />
      <SocialSource />
    </BRow>
  </div>
</template>

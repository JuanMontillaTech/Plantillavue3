<script>
import MessageTab from "~/components/contacts/profile/Message.vue";
import TaskTab from "~/components/contacts/profile/Task.vue";
import AboutTab from "~/components/contacts/profile/About.vue";
/**
 * Profile component
 */
export default {
  components: {
    MessageTab,
    TaskTab,
    AboutTab
  }
};
</script>

<template>
  <div>
    <BRow class="mb-4">
      <BCol cols="xl-4">
        <BCard no-body class="h-100">
          <BCardBody>
            <div class="text-center">
              <BDropdown class="float-end" variant="white" right toggle-class="font-size-16 text-body p-0">
                <template v-slot:button-content>
                  <i class="uil uil-ellipsis-v"></i>
                </template>
                <BDropdownItem href="#">Edit</BDropdownItem>
                <BDropdownItem href="#">Action</BDropdownItem>
                <BDropdownItem href="#">Remove</BDropdownItem>
              </BDropdown>
              <div class="clearfix"></div>
              <div>
                <img src="/images/users/avatar-4.jpg" alt class="avatar-lg rounded-circle img-thumbnail" />
              </div>
              <h5 class="mt-3 mb-1">Marcus</h5>
              <p class="text-muted">UI/UX Designer</p>

              <div class="mt-4">
                <BButton variant="light" size="sm">
                  <i class="uil uil-envelope-alt me-2"></i> Message
                </BButton>
              </div>
            </div>

            <hr class="my-4" />

            <div class="text-muted">
              <h5 class="font-size-16">About</h5>
              <p>
                Hi I'm Marcus,has been the industry's standard dummy text To an
                English person, it will seem like simplified English, as a
                skeptical Cambridge.
              </p>
              <div class="table-responsive mt-4 mb-0">
                <div>
                  <p class="mb-1">Name :</p>
                  <h5 class="font-size-16">Marcus</h5>
                </div>
                <div class="mt-4">
                  <p class="mb-1">Mobile :</p>
                  <h5 class="font-size-16">012-234-5678</h5>
                </div>
                <div class="mt-4">
                  <p class="mb-1">E-mail :</p>
                  <h5 class="font-size-16">marcus@minible.com</h5>
                </div>
                <div class="mt-4">
                  <p class="mb-1">Location :</p>
                  <h5 class="font-size-16">California, United States</h5>
                </div>
              </div>
            </div>
          </BCardBody>
        </BCard>
      </BCol>

      <BCol cols="xl-8">
        <BCard no-body class="mb-0">
          <BTabs content-class="p-4" justified class="nav-tabs-custom contact-profile">
            <BTab active>
              <template #title>
                <i class="uil uil-user-circle font-size-20"></i>
                <span class="d-none d-sm-block">About</span>
              </template>
              <AboutTab />
            </BTab>
            <BTab>
              <template #title>
                <i class="uil uil-clipboard-notes font-size-20"></i>
                <span class="d-none d-sm-block">Tasks</span>
              </template>
              <TaskTab />
            </BTab>
            <BTab>
              <template #title>
                <i class="uil uil-envelope-alt font-size-20"></i>
                <span class="d-none d-sm-block">Messages</span>
              </template>
              <MessageTab />
            </BTab>
          </BTabs>
        </BCard>
      </BCol>
    </BRow>
  </div>
</template>

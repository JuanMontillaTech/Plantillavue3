<script>
export default {};
</script>
<template>
  <div>
    <h5 class="font-size-16 mb-3">Active</h5>

    <div class="table-responsive">
      <BTableSimple class="table-nowrap table-centered">
        <BTbody>
          <BTr>
            <BTd style="width: 60px">
              <div class="form-check">
                <input type="checkbox" class="form-check-input" id="tasks-activeCheck2" />
                <label class="form-check-label" for="tasks-activeCheck2"></label>
              </div>
            </BTd>
            <BTd>
              <a href="#" class="font-weight-bold nav-link">Ecommerce Product Detail</a>
            </BTd>

            <BTd>27 May, 2020</BTd>
            <BTd style="width: 160px">
              <span class="badge bg-soft-primary font-size-12">Active</span>
            </BTd>
          </BTr>
          <BTr>
            <BTd>
              <div class="form-check">
                <input type="checkbox" class="form-check-input" id="tasks-activeCheck1" />
                <label class="form-check-label" for="tasks-activeCheck1"></label>
              </div>
            </BTd>
            <BTd>
              <a href="#" class="font-weight-bold nav-link">Ecommerce Product</a>
            </BTd>

            <BTd>26 May, 2020</BTd>
            <BTd>
              <span class="badge bg-soft-primary font-size-12">Active</span>
            </BTd>
          </BTr>
        </BTbody>
      </BTableSimple>
    </div>

    <h5 class="font-size-16 my-3">Upcoming</h5>

    <div class="table-responsive">
      <BTableSimple class="table-nowrap table-centered">
        <BTbody>
          <BTr>
            <BTd style="width: 60px">
              <div class="form-check">
                <input type="checkbox" class="form-check-input" id="tasks-upcomingCheck3" />
                <label class="form-check-label" for="tasks-upcomingCheck3"></label>
              </div>
            </BTd>
            <BTd>
              <a href="#" class="font-weight-bold nav-link">Chat app Page</a>
            </BTd>

            <BTd>-</BTd>
            <BTd style="width: 160px">
              <span class="badge bg-soft-secondary font-size-12">Waiting</span>
            </BTd>
          </BTr>
          <BTr>
            <BTd>
              <div class="form-check">
                <input type="checkbox" class="form-check-input" id="tasks-upcomingCheck2" />
                <label class="form-check-label" for="tasks-upcomingCheck2"></label>
              </div>
            </BTd>
            <BTd>
              <a href="#" class="font-weight-bold nav-link">Email Pages</a>
            </BTd>

            <BTd>04 June, 2020</BTd>
            <BTd>
              <span class="badge bg-soft-primary font-size-12">Approved</span>
            </BTd>
          </BTr>
          <BTr>
            <BTd>
              <div class="form-check">
                <input type="checkbox" class="form-check-input" id="tasks-upcomingCheck1" />
                <label class="form-check-label" for="tasks-upcomingCheck1"></label>
              </div>
            </BTd>
            <BTd>
              <a href="#" class="font-weight-bold nav-link">Contacts Profile Page</a>
            </BTd>

            <BTd>-</BTd>
            <BTd>
              <span class="badge bg-soft-secondary font-size-12">Waiting</span>
            </BTd>
          </BTr>
        </BTbody>
      </BTableSimple>
    </div>

    <h5 class="font-size-16 my-3">Complete</h5>

    <div class="table-responsive">
      <BTableSimple class="table-nowrap table-centered">
        <BTbody>
          <BTr>
            <BTd style="width: 60px">
              <div class="form-check">
                <input type="checkbox" class="form-check-input" id="tasks-completeCheck3" />
                <label class="form-check-label" for="tasks-completeCheck3"></label>
              </div>
            </BTd>
            <BTd>
              <a href="#" class="font-weight-bold nav-link">UI Elements</a>
            </BTd>

            <BTd>27 May, 2020</BTd>
            <BTd style="width: 160px">
              <span class="badge bg-soft-success font-size-12">Complete</span>
            </BTd>
          </BTr>
          <BTr>
            <BTd>
              <div class="form-check">
                <input type="checkbox" class="form-check-input" id="tasks-completeCheck2" />
                <label class="form-check-label" for="tasks-completeCheck2"></label>
              </div>
            </BTd>
            <BTd>
              <a href="#" class="font-weight-bold nav-link">Authentication Pages</a>
            </BTd>

            <BTd>27 May, 2020</BTd>
            <BTd>
              <span class="badge bg-soft-success font-size-12">Complete</span>
            </BTd>
          </BTr>
          <BTr>
            <BTd>
              <div class="form-check">
                <input type="checkbox" class="form-check-input" id="tasks-completeCheck1" />
                <label class="form-check-label" for="tasks-completeCheck1"></label>
              </div>
            </BTd>
            <BTd>
              <a href="#" class="font-weight-bold nav-link">Admin Layout</a>
            </BTd>

            <BTd>26 May, 2020</BTd>
            <BTd>
              <span class="badge bg-soft-success font-size-12">Complete</span>
            </BTd>
          </BTr>
        </BTbody>
      </BTableSimple>
    </div>
  </div>
</template>

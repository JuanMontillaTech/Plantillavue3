<script>
import Avatar3 from "~/public/images/users/avatar-3.jpg";
import Avatar4 from "~/public/images/users/avatar-4.jpg";
import Avatar5 from "~/public/images/users/avatar-5.jpg";
import Avatar7 from "~/public/images/users/avatar-7.jpg";
export default {
  name: "Message",
  data() {
    return {
      data: [
        {
          image: Avatar3,
          name: "Marion Walker",
          time: "1 hr ago",
          description:
            "If several languages coalesce, the grammar of the resulting .",
          childData: [
            {
              image: Avatar4,
              name: "Shanon Marvin",
              time: "1 hr ago",
              description:
                "It will be as simple as in fact, it will be Occidental. To it will seem like simplified ."
            }
          ]
        },
        {
          image: Avatar5,
          name: "Janice Morgan",
          time: "2 hr ago",
          description:
            "To achieve this, it would be necessary to have uniform pronunciation."
        },
        {
          image: Avatar7,
          name: "Patrick Petty",
          time: "3 hr ago",
          description: "Sed ut perspiciatis unde omnis iste natus error sit"
        }
      ]
    };
  }
};
</script>

<template>
  <div>
    <div data-simplebar style="max-height: 430px">
      <div v-for="(msg, index) in data" :key="index" class="media border-bottom py-4">
        <BRow no-gutters>
          <BCol cols="auto">
            <img class="me-2 rounded-circle avatar-xs" :src="msg.image" alt="" />
          </BCol>
          <BCol>
            <div class="media-body">
              <h5 class="font-size-15 mt-0 mb-1">{{ msg.name }}</h5>
              <p class="text-muted">
                {{ msg.description }}
              </p>

              <a href="#" class="text-muted font-13 d-inline-block">
                <i class="mdi mdi-reply"></i> Reply
              </a>
            </div>
          </BCol>
          <BCol>
            <h5 class="font-size-15 mt-0 mb-1">
              <small class="text-muted float-end"> {{ msg.time }} </small>
            </h5>
          </BCol>
        </BRow>
        <div v-if="msg.childData" class="media ms-5 mt-4">
          <BRow v-for="(childMsg, childIndex) in msg.childData" :key="childIndex" no-gutters>
            <BCol cols="auto">
              <img class="me-2 rounded-circle avatar-xs" :src="childMsg.image" alt="" />
            </BCol>
            <BCol>
              <div class="media-body">
                <h5 class="font-size-15 mt-0 mb-1">{{ childMsg.name }}</h5>
                <p class="text-muted">
                  {{ childMsg.description }}
                </p>

                <a href="#" class="text-muted font-13 d-inline-block">
                  <i class="mdi mdi-reply"></i> Reply
                </a>
              </div>
            </BCol>
            <BCol>
              <h5 class="font-size-15 mt-0 mb-1">
                <small class="text-muted float-end">
                  {{ childMsg.time }}
                </small>
              </h5>
            </BCol>
          </BRow>
        </div>
      </div>
    </div>
    <div class="border rounded mt-4">
      <BForm action="#">
        <div class="px-2 py-1 bg-light">
          <div class="btn-group" role="group">
            <BButton type="button" class="btn-sm btn-link text-dark text-decoration-none">
              <i class="uil uil-link"></i>
            </BButton>
            <BButton type="button" class="btn-sm btn-link text-dark text-decoration-none">
              <i class="uil uil-smile"></i>
            </BButton>
            <BButton type="button" class="btn-sm btn-link text-dark text-decoration-none">
              <i class="uil uil-at"></i>
            </BButton>
          </div>
        </div>
        <textarea rows="3" class="form-control border-0 resize-none" placeholder="Your Message..."></textarea>
      </BForm>
    </div>
  </div>
</template>

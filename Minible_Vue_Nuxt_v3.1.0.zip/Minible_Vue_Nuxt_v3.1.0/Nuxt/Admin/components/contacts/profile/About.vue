<script>
export default {};
</script>

<template>
  <div>
    <div>
      <h5 class="font-size-16 mb-4">Experience</h5>

      <ul class="activity-feed mb-0 pl-2">
        <li class="feed-item">
          <div class="feed-item-list">
            <p class="text-muted mb-1">2019 - 2020</p>
            <h5 class="font-size-16">UI/UX Designer</h5>
            <p>Abc Company</p>
            <p class="text-muted">
              To achieve this, it would be necessary to have uniform grammar,
              pronunciation and more common words. If several languages
              coalesce, the grammar of the resulting language is more simple and
              regular than that of the individual
            </p>
          </div>
        </li>
        <li class="feed-item">
          <div class="feed-item-list">
            <p class="text-muted mb-1">2017 - 2019</p>
            <h5 class="font-size-16">Graphic Designer</h5>
            <p>xyz Company</p>
            <p class="text-muted">
              It will be as simple as occidental in fact, it will be Occidental.
              To an English person, it will seem like simplified English, as a
              skeptical Cambridge friend of mine told me what Occidental
            </p>
          </div>
        </li>
      </ul>
    </div>

    <div>
      <h5 class="font-size-16 mb-4">Projects</h5>

      <div class="table-responsive">
        <BTableSimple class="table-nowrap table-hover mb-0">
          <BThead>
            <BTr>
              <BTh scope="col">#</BTh>
              <BTh scope="col">Projects</BTh>
              <BTh scope="col">Date</BTh>
              <BTh scope="col">Status</BTh>
              <BTh scope="col" style="width: 120px">Action</BTh>
            </BTr>
          </BThead>
          <BTbody>
            <BTr>
              <BTh scope="row">01</BTh>
              <BTd>
                <a href="#" class="nav-link">Brand Logo Design</a>
              </BTd>
              <BTd>18 Jun, 2020</BTd>
              <BTd>
                <span class="badge bg-soft-primary font-size-12">Open</span>
              </BTd>
              <BTd>
                <BDropdown right toggle-class="text-muted font-size-18 px-2 p-0" variant="white">
                  <template v-slot:button-content>
                    <i class="uil uil-ellipsis-v"></i>
                  </template>

                  <BDropdownItem href="#">Action</BDropdownItem>
                  <BDropdownItem href="#">Another action</BDropdownItem>
                  <BDropdownItem href="#">Something else here</BDropdownItem>
                </BDropdown>
              </BTd>
            </BTr>
            <BTr>
              <BTh scope="row">02</BTh>
              <BTd>
                <a href="#" class="nav-link">Minible Admin</a>
              </BTd>
              <BTd>06 Jun, 2020</BTd>
              <BTd>
                <span class="badge bg-soft-primary font-size-12">Open</span>
              </BTd>
              <BTd>
                <BDropdown right toggle-class="text-muted font-size-18 px-2 p-0" variant="white">
                  <template v-slot:button-content>
                    <i class="uil uil-ellipsis-v"></i>
                  </template>

                  <BDropdownItem href="#">Action</BDropdownItem>
                  <BDropdownItem href="#">Another action</BDropdownItem>
                  <BDropdownItem href="#">Something else here</BDropdownItem>
                </BDropdown>
              </BTd>
            </BTr>
            <BTr>
              <BTh scope="row">03</BTh>
              <BTd>
                <a href="#" class="nav-link">Chat app Design</a>
              </BTd>
              <BTd>28 May, 2020</BTd>
              <BTd>
                <span class="badge bg-soft-success font-size-12">Complete</span>
              </BTd>
              <BTd>
                <BDropdown right toggle-class="text-muted font-size-18 px-2 p-0" variant="white">
                  <template v-slot:button-content>
                    <i class="uil uil-ellipsis-v"></i>
                  </template>

                  <BDropdownItem href="#">Action</BDropdownItem>
                  <BDropdownItem href="#">Another action</BDropdownItem>
                  <BDropdownItem href="#">Something else here</BDropdownItem>
                </BDropdown>
              </BTd>
            </BTr>
            <BTr>
              <BTh scope="row">04</BTh>
              <BTd>
                <a href="#" class="nav-link">Minible Landing</a>
              </BTd>
              <BTd>13 May, 2020</BTd>
              <BTd>
                <span class="badge bg-soft-success font-size-12">Complete</span>
              </BTd>
              <BTd>
                <BDropdown right toggle-class="text-muted font-size-18 px-2 p-0" variant="white">
                  <template v-slot:button-content>
                    <i class="uil uil-ellipsis-v"></i>
                  </template>

                  <BDropdownItem href="#">Action</BDropdownItem>
                  <BDropdownItem href="#">Another action</BDropdownItem>
                  <BDropdownItem href="#">Something else here</BDropdownItem>
                </BDropdown>
              </BTd>
            </BTr>
            <BTr>
              <BTh scope="row">05</BTh>
              <BTd>
                <a href="#" class="nav-link">Authentication Pages</a>
              </BTd>
              <BTd>06 May, 2020</BTd>
              <BTd>
                <span class="badge bg-soft-success font-size-12">Complete</span>
              </BTd>
              <BTd>
                <BDropdown right toggle-class="text-muted font-size-18 px-2 p-0" variant="white">
                  <template v-slot:button-content>
                    <i class="uil uil-ellipsis-v"></i>
                  </template>

                  <BDropdownItem href="#">Action</BDropdownItem>
                  <BDropdownItem href="#">Another action</BDropdownItem>
                  <BDropdownItem href="#">Something else here</BDropdownItem>
                </BDropdown>
              </BTd>
            </BTr>
          </BTbody>
        </BTableSimple>
      </div>
    </div>
  </div>
</template>

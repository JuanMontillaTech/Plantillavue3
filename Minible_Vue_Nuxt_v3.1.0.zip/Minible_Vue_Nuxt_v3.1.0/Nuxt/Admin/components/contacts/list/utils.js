import Avatar2 from "~/public/images/users/avatar-2.jpg";
import Avatar3 from "~/public/images/users/avatar-3.jpg";
import Avatar4 from "~/public/images/users/avatar-4.jpg";
// import Avatar5 from "~/public/images/users/avatar-5.jpg";
import Avatar7 from "~/public/images/users/avatar-7.jpg";
import Avatar8 from "~/public/images/users/avatar-8.jpg";

export const userList = [
  {
    id: 1,
    profile: Avatar2,
    name: "Simon Ryles",
    position: "Full Stack Developer",
    email: "SimonRyles@minible.com",
  },
  {
    id: 2,
    profile: Avatar3,
    name: "Marion Walker",
    position: "Frontend Developer",
    email: "MarionWalker@minible.com",
  },
  {
    id: 3,
    name: "Frederick White",
    position: "Frontend Developer",
    email: "MarionWalker@minible.com",
  },
  {
    id: 4,
    profile: Avatar4,
    name: "Shanon Marvin",
    position: "Backend Developer",
    email: "ShanonMarvin@minible.com",
  },
  {
    id: 5,
    name: "Mark Jones",
    position: "Frontend Developer",
    email: "MarkJones@minible.com",
  },
  {
    id: 6,
    profile: Avatar7,
    name: "Patrick Petty",
    position: "UI/UX Designer",
    email: "PatrickPetty@minible.com",
  },
  {
    id: 7,
    profile: Avatar8,
    name: "Marilyn Horton",
    position: "Backend Developer",
    email: "MarilynHorton@minible.com",
  },
  {
    id: 8,
    profile: Avatar2,
    name: "Neal Womack",
    position: "Full Stack Developer",
    email: "NealWomack@minible.com",
  },
  {
    id: 9,
    profile: Avatar2,
    name: "Steven Williams",
    position: "Frontend Developer",
    email: "StevenWilliams@minible.com",
  },
];

export const fields = [
  {
    key: "check",
    label: "",
  },
  {
    key: "name",
  },
  {
    key: "position",
  },
  {
    key: "email",
  },
  "action",
];

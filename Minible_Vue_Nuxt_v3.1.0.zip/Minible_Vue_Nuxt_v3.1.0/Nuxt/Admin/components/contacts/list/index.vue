<script>
import { userList, fields } from "~/components/contacts/list/utils.js";
/**
 * User list component
 */
export default {
  data() {
    return {
      userList,
      totalRows: 1,
      currentPage: 1,
      perPage: 10,
      pageOptions: [10, 25, 50, 100],
      filter: null,
      filterOn: [],
      sortBy: "age",
      sortDesc: false,
      fields
    };
  },
  computed: {
    /**
     * Total no. of records
     */
    rows() {
      return this.userList.length;
    }
  },
  mounted() {
    // Set the initial number of items
    this.totalRows = this.userList.length;
  },
  methods: {
    /**
     * Search the table data with search input
     */
    onFiltered(filteredItems) {
      // Trigger pagination to update the number of buttons/pages due to filtering
      this.totalRows = filteredItems.length;
      this.currentPage = 1;
    }
  }
};
</script>

<template>
  <div>
    <BRow>
      <BCol cols="12">
        <BCard no-body>
          <BCardBody>
            <BRow class="mt-4">
              <BCol sm="12" md="6">
                <div id="tickets-table_length" class="dataTables_length">
                  <label class="d-inline-flex align-items-center">
                    Show&nbsp;
                    <BFormSelect v-model="perPage" size="sm" :options="pageOptions"></BFormSelect>&nbsp;entries
                  </label>
                </div>
              </BCol>
              <BCol sm="12" md="6">
                <div id="tickets-table_filter" class="dataTables_filter text-md-end">
                  <label class="d-inline-flex align-items-center">
                    Search:
                    <BFormInput v-model="filter" type="search" class="form-control form-control-sm ms-2"></BFormInput>
                  </label>
                </div>
              </BCol>
            </BRow>
            <div class="table-responsive mb-0">
              <BTable class="table table-centered table-nowrap" :items="userList" :fields="fields" responsive="sm" :per-page="perPage" :current-page="currentPage" v-model:sort-by.sync="sortBy" v-model:sort-desc.sync="sortDesc" :filter="filter" :filter-included-fields="filterOn" @filtered="onFiltered">
                <template v-slot:cell(check)="data">
                  <div class="custom-control custom-checkbox text-center font-size-16">
                    <input type="checkbox" class="form-check-input" :id="`contacusercheck${data.item.id}`" />
                  </div>
                </template>
                <template v-slot:cell(name)="data">
                  <img v-if="data.item.profile" :src="data.item.profile" alt class="avatar-xs rounded-circle me-2" />
                  <div v-if="!data.item.profile" class="avatar-xs d-inline-block me-2">
                    <div class="avatar-title bg-primary-subtle rounded-circle text-primary">
                      <i class="mdi mdi-account-circle m-0"></i>
                    </div>
                  </div>
                  <a href="#" class="text-body">{{ data.item.name }}</a>
                </template>
                <template v-slot:cell(action)>
                  <ul class="list-inline mb-0">
                    <li class="list-inline-item">
                      <a href="#" class="px-2 text-primary" v-b-tooltip.hover title="Edit">
                        <i class="uil uil-pen font-size-18"></i>
                      </a>
                    </li>
                    <li class="list-inline-item">
                      <a href="#" class="px-2 text-danger" v-b-tooltip.hover title="Delete">
                        <i class="uil uil-trash-alt font-size-18"></i>
                      </a>
                    </li>
                    <BDropdown class="list-inline-item" variant="white" right toggle-class="text-muted font-size-18 px-2">
                      <template v-slot:button-content>
                        <i class="uil uil-ellipsis-v"></i>
                      </template>
                      <BDropdownItem href="#">Action</BDropdownItem>
                      <BDropdownItem href="#">Another action</BDropdownItem>
                      <BDropdownItem href="#">Something else here</BDropdownItem>
                    </BDropdown>
                  </ul>
                </template>
              </BTable>
            </div>
            
            <BRow>
              <BCol>
                <div class="dataTables_paginate paging_simple_numbers float-end">
                  <ul class="pagination pagination-rounded mb-0">
                    <BPagination v-model="currentPage" :total-rows="rows" :per-page="perPage" />
                  </ul>
                </div>
              </BCol>
            </BRow>
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>
  </div>
</template>

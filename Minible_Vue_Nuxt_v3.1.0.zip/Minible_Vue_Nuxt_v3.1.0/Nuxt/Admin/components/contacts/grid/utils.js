import Avatar2 from "~/public/images/users/avatar-2.jpg";
import Avatar3 from "~/public/images/users/avatar-3.jpg";
import Avatar4 from "~/public/images/users/avatar-4.jpg";
import Avatar5 from "~/public/images/users/avatar-5.jpg";
import Avatar7 from "~/public/images/users/avatar-7.jpg";
import Avatar8 from "~/public/images/users/avatar-8.jpg";

export const gridList = [
  {
    profile: Avatar2,
    name: "Simon Ryles",
    designation: "Full Stack Developer",
  },
  {
    profile: Avatar3,
    name: "Marion Walker",
    designation: "Frontend Developer",
  },
  {
    name: "Frederick White",
    designation: "UI/UX Designer",
  },
  {
    profile: Avatar4,
    name: "Shanon Marvin",
    designation: "Backend Developer",
  },
  {
    name: "Mark Jones",
    designation: "Frontend Developer",
  },
  {
    profile: Avatar5,
    name: "Janice Morgan",
    designation: "Backend Developer",
  },
  {
    profile: Avatar7,
    name: "Patrick Petty",
    designation: "UI/UX Designer",
  },
  {
    profile: Avatar8,
    name: "Marilyn Horton",
    designation: "Frontend Developer",
  },
];

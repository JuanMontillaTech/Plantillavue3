<script>
import { gridList } from "~/components/contacts/grid/utils.js";
/**
 * User grid component
 */
export default {
  data() {
    return {
      gridList
    };
  }
};
</script>

<template>
  <div>
    <BRow>
      <BCol cols="xl-3" sm="6" v-for="(item, index) in gridList" :key="index">
        <BCard no-body class="text-center">
          <BCardBody>
            <BDropdown class="float-end" variant="white" right toggle-class="font-size-16 text-body p-0">
              <template v-slot:button-content>
                <i class="uil uil-ellipsis-h"></i>
              </template>
              <a class="dropdown-item" href="#">Edit</a>
              <a class="dropdown-item" href="#">Action</a>
              <a class="dropdown-item" href="#">Remove</a>
            </BDropdown>
            <div class="clearfix"></div>
            <div class="mb-4">
              <img v-if="item.profile" :src="item.profile" alt class="avatar-lg rounded-circle img-thumbnail" />
              <div class="avatar-lg mx-auto mb-4" v-if="!item.profile">
                <div class="avatar-title bg-primary-subtle rounded-circle text-primary">
                  <i class="mdi mdi-account-circle display-4 m-0 text-primary"></i>
                </div>
              </div>
            </div>
            <h5 class="font-size-16 mb-1">
              <a href="#" class="nav-link">{{ item.name }}</a>
            </h5>
            <p class="text-muted mb-2">{{ item.designation }}</p>
          </BCardBody>

          <BButtonGroup>
            <BButton variant="outline-light" class="text-truncate">
              <i class="uil uil-user me-1"></i> Profile
            </BButton>
            <BButton variant="outline-light" class="text-truncate">
              <i class="uil uil-envelope-alt me-1"></i> Message
            </BButton>
          </BButtonGroup>
        </BCard>
      </BCol>
    </BRow>

    <BRow class="mt-3">
      <BCol cols="xl-12">
        <div class="text-center my-3">
          <a href="#" class="text-primary">
            <i class="mdi mdi-loading mdi-spin font-size-20 align-middle me-2"></i>
            Load more
          </a>
        </div>
      </BCol>
    </BRow>
  </div>
</template>

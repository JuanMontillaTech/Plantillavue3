<script>
import {
  linewithDataChart,
  dashedLineChart,
  splineAreaChart,
  columnChart,
  columnDatalabelChart,
  barChart,
  mixedChart,
  radialChart,
  pieChart,
  donutChart
} from "~/components/charts/apex/utils.js";

/**
 * Apex-chart component
 */
export default {
  data() {
    return {
      linewithDataChart,
      dashedLineChart,
      splineAreaChart,
      columnChart,
      columnDatalabelChart,
      barChart,
      mixedChart,
      radialChart,
      pieChart,
      donutChart
    };
  }
};
</script>

<template>
  <div>
    <BRow>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Line With Data Labels</BCardTitle>
            <apexchart class="apex-charts" height="380" type="line" dir="ltr" :series="linewithDataChart.series" :options="linewithDataChart.chartOptions" />
          </BCardBody>
        </BCard>
      </BCol>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Dashed Line</BCardTitle>
            <apexchart class="apex-charts" height="380" type="line" dir="ltr" :series="dashedLineChart.series" :options="dashedLineChart.chartOptions" />
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>
    <BRow>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Spline Area</BCardTitle>
            <apexchart class="apex-charts" height="350" type="area" dir="ltr" :series="splineAreaChart.series" :options="splineAreaChart.chartOptions" />
          </BCardBody>
        </BCard>
      </BCol>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Column Charts</BCardTitle>
            <apexchart class="apex-charts" height="350" type="bar" dir="ltr" :series="columnChart.series" :options="columnChart.chartOptions" />
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>
    <BRow>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Column With Data Labels</BCardTitle>
            <apexchart class="apex-charts" height="350" type="bar" dir="ltr" :series="columnDatalabelChart.series" :options="columnDatalabelChart.chartOptions" />
          </BCardBody>
        </BCard>
      </BCol>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Bar Chart</BCardTitle>
            <apexchart class="apex-charts" height="350" type="bar" dir="ltr" :series="barChart.series" :options="barChart.chartOptions" />
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>
    <BRow>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Line, Column & Area Chart</BCardTitle>
            <apexchart class="apex-charts" height="350" type="line" dir="ltr" :series="mixedChart.series" :options="mixedChart.chartOptions" />
          </BCardBody>
        </BCard>
      </BCol>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Radial Chart</BCardTitle>
            <apexchart class="apex-charts" height="380" type="radialBar" dir="ltr" :series="radialChart.series" :options="radialChart.chartOptions" />
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>
    <BRow>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Pie Chart</BCardTitle>
            <apexchart class="apex-charts" height="320" type="pie" dir="ltr" :series="pieChart.series" :options="pieChart.chartOptions" />
          </BCardBody>
        </BCard>
      </BCol>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Donut Chart</BCardTitle>
            <apexchart class="apex-charts" height="320" type="donut" dir="ltr" :series="donutChart.series" :options="donutChart.chartOptions" />
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>
  </div>
</template>

<script>
import SmilAnimation from "~/components/charts/chartist/components/SmillAnimation.vue";
import LineChart from "~/components/charts/chartist/components/LineChart.vue";
import LineChartWithArea from "~/components/charts/chartist/components/LineChartWithArea.vue";
import BiPolarChart from "~/components/charts/chartist/components/BiPolarChart.vue";
import LineInterpolation from "~/components/charts/chartist/components/LineInterpolation.vue";
import OverlappingBarChart from "~/components/charts/chartist/components/OverlappingBarChart.vue";
import StackBarChart from "~/components/charts/chartist/components/StackBarChart.vue";
import HorizontalBarChart from "~/components/charts/chartist/components/HorizontalBarChart.vue";
import DistributedSeries from "~/components/charts/chartist/components/DistributedSeries.vue";
import LabelPlacementChart from "~/components/charts/chartist/components/LabelPlacementChart.vue";
import ExtremeConfigChart from "~/components/charts/chartist/components/ExtremeConfigChart.vue";
import PolarBarChart from "~/components/charts/chartist/components/PolarBarChart.vue";
import DonutAnimationChart from "~/components/charts/chartist/components/DonutAnimationChart.vue";
import SimplePieChart from "~/components/charts/chartist/components/SimplePieChart.vue";
import CommonLayout from "~/components/charts/chartist/components/CommonLayout.vue";
// import "chartist/dist/index.scss";
/**
 * Chartist-chart component
 */
export default {
  components: {
    SmilAnimation,
    LineChart,
    LineChartWithArea,
    BiPolarChart,
    LineInterpolation,
    OverlappingBarChart,
    StackBarChart,
    HorizontalBarChart,
    DistributedSeries,
    LabelPlacementChart,
    ExtremeConfigChart,
    PolarBarChart,
    DonutAnimationChart,
    SimplePieChart,
    CommonLayout
  }
};
</script>

<template>
  <div>
    <BRow>
      <BCol lg="6">
        <CommonLayout>
          <template #name>Advanced Smil Animations</template>
          <SmilAnimation class="ct-chart" />
        </CommonLayout>
      </BCol>

      <BCol lg="6">
        <CommonLayout>
          <template #name>Simple Line Chart</template>
          <LineChart class="ct-chart" />
        </CommonLayout>
      </BCol>
      <BCol lg="6">
        <CommonLayout>
          <template #name>Line Chart With Area</template>
          <LineChartWithArea class="ct-chart" />
        </CommonLayout>
      </BCol>

      <BCol lg="6">
        <CommonLayout>
          <template #name>Bi-polar Line Chart Wth Area Only</template>
          <BiPolarChart class="ct-chart" />
        </CommonLayout>
      </BCol>
      <BCol lg="6">
        <CommonLayout>
          <template #name>Line Interpolation / Smoothing</template>
          <LineInterpolation class="ct-chart" />
        </CommonLayout>
      </BCol>

      <BCol lg="6">
        <CommonLayout>
          <template #name>Overlapping Bars On Mobile</template>
          <OverlappingBarChart class="ct-chart" />
        </CommonLayout>
      </BCol>
      <BCol lg="6">
        <CommonLayout>
          <template #name>Stacked Bar Chart</template>
          <StackBarChart class="ct-chart" />
        </CommonLayout>
      </BCol>

      <BCol lg="6">
        <CommonLayout>
          <template #name>Horizontal Bar Chart</template>
          <HorizontalBarChart class="ct-chart" />
        </CommonLayout>
      </BCol>
      <BCol lg="6">
        <CommonLayout>
          <template #name>Distributed Series</template>
          <DistributedSeries class="ct-chart" />
        </CommonLayout>
      </BCol>

      <BCol lg="6">
        <CommonLayout>
          <template #name>Label Placement</template>
          <LabelPlacementChart class="ct-chart" />
        </CommonLayout>
      </BCol>
      <BCol lg="6">
        <CommonLayout>
          <template #name>Extreme Responsive Configuration</template>
          <ExtremeConfigChart class="ct-chart" />
        </CommonLayout>
      </BCol>
      <BCol lg="6">
        <CommonLayout>
          <template #name>Bi-polar Bar Chart</template>
          <PolarBarChart class="ct-chart" />
        </CommonLayout>
      </BCol>
      <BCol lg="6">
        <CommonLayout>
          <template #name>Donut With Svg.animate</template>
          <DonutAnimationChart class="ct-chart" />
        </CommonLayout>
      </BCol>

      <BCol lg="6">
        <CommonLayout>
          <template #name>Simple Pie Chart</template>
          <SimplePieChart class="ct-chart" />
        </CommonLayout>
      </BCol>
    </BRow>
  </div>
</template>

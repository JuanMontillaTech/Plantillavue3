<script>
import LineChart from "~/components/charts/eChart/components/LineChart.vue";
import MixBarChart from "~/components/charts/eChart/components/MixBarChart.vue";
import PieChart from "~/components/charts/eChart/components/PieChart.vue";
import DonutChart from "~/components/charts/eChart/components/DonutChart.vue";
import CandleStickChart from "~/components/charts/eChart/components/CandleStickChart.vue";
import GaugeChart from "~/components/charts/eChart/components/GaugeChart.vue";
import BubbleChart from "~/components/charts/eChart/components/BubbleChart.vue";
import PolarChart from "~/components/charts/eChart/components/PolarChart.vue";

export default {
  components: {
    LineChart,
    MixBarChart,
    PieChart,
    DonutChart,
    CandleStickChart,
    GaugeChart,
    BubbleChart,
    PolarChart
  }
};
</script>

<template>
  <div>
    <BRow>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Line Chart</BCardTitle>
            <LineChart />
          </BCardBody>
        </BCard>
      </BCol>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Mix Line-Bar</BCardTitle>
            <MixBarChart />
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>

    <BRow>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Pie Chart</BCardTitle>
            <PieChart />
          </BCardBody>
        </BCard>
      </BCol>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Doughnut Chart</BCardTitle>
            <DonutChart />
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>
    <BRow>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Candle Stick Chart</BCardTitle>
            <CandleStickChart />
          </BCardBody>
        </BCard>
      </BCol>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Gauge Chart</BCardTitle>
            <GaugeChart />
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>
    <BRow>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Bubble Chart</BCardTitle>
            <BubbleChart />
          </BCardBody>
        </BCard>
      </BCol>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Polar Chart</BCardTitle>
            <PolarChart />
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>
  </div>
</template>

<script>
import LineChart from "~/components/charts/chartjs/components/LineChart.vue";
import BarChart from "~/components/charts/chartjs/components/BarChart.vue";
import PieChart from "~/components/charts/chartjs/components/PieChart.vue";
import DonutChart from "~/components/charts/chartjs/components/DonutChart.vue";
import PolarChart from "~/components/charts/chartjs/components/PolarChart.vue";
import RadarChart from "~/components/charts/chartjs/components/RadarChart.vue";

/**
 * Chartjs-chart component
 */
export default {
  components: {
    LineChart,
    BarChart,
    PieChart,
    DonutChart,
    PolarChart,
    RadarChart
  }
};
</script>

<template>
  <div>
    <BRow>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Line Chart</BCardTitle>
            <LineChart />
          </BCardBody>
        </BCard>
      </BCol>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Bar Chart</BCardTitle>
            <BarChart />
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>

    <BRow>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Pie Chart</BCardTitle>
            <div class="d-flex justify-content-center">
              <PieChart />
            </div>
          </BCardBody>
        </BCard>
      </BCol>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Donut Chart</BCardTitle>
            <div class="d-flex justify-content-center">
              <DonutChart />
            </div>
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>

    <BRow>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Polar area Chart</BCardTitle>
            <div class="d-flex justify-content-center">
              <PolarChart />
            </div>
          </BCardBody>
        </BCard>
      </BCol>
      <BCol lg="6">
        <BCard no-body>
          <BCardBody>
            <BCardTitle class="mb-4">Radar Chart</BCardTitle>
            <div class="d-flex justify-content-center">
              <RadarChart />
            </div>
          </BCardBody>
        </BCard>
      </BCol>
    </BRow>
  </div>
</template>

<style lang="scss">
.chart-wrapper {
  max-height: 320px !important;
  width: 100% !important;
}
</style>

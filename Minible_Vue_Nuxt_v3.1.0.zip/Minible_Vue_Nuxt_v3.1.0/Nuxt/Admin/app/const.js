export const LAYOUT_TYPE = {
  VERTICAL: "vertical",
  HORIZONTAL: "horizontal"
};

export const LAYOUT_MODE = {
  LIGHT: "light",
  DARK: "dark"
};

export const GOOGLE_API_KEY = "AIzaSyAbvyBxmMbFhrzP9Z8moyYr6dCr-pzjhBE";

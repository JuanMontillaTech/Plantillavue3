import ar from "~/app/modules/locales/ar.json";
import en from "~/app/modules/locales/en.json";
import es from "~/app/modules/locales/es.json";
import fr from "~/app/modules/locales/fr.json";
import zh from "~/app/modules/locales/zh.json";

export default { ar, en, es, fr, zh };

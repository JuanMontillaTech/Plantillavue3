<script>
import CalenderComponent from "~/components/calender/index.vue";
export default {
  components: {
    CalenderComponent
  },
  data() {
    return {
      title: "Calendar",
      items: [
        {
          text: "Apps",
        },
        {
          text: "Calendar",
          active: true
        }
      ]
    };
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <CalenderComponent />
</template>
FF
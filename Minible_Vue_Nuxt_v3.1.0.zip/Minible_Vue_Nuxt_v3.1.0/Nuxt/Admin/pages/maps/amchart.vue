<script>
import AMChart from "~/components/maps/amchart/index.vue";
export default {
  data() {
    return {
      title: "Amchart map",
      items: [
        {
          text: "Maps",
          href: "/"
        },
        {
          text: "Amchart map",
          active: true
        }
      ]
    };
  },
  components: {
    AMChart
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <AMChart />
</template>

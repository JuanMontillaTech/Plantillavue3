<script>
import GoogleMap from "~/components/maps/google/index.vue";
export default {
  data() {
    return {
      title: "Google Maps",
      items: [
        {
          text: "Maps",
          href: "/"
        },
        {
          text: "Google Maps",
          active: true
        }
      ]
    };
  },
  components: {
    GoogleMap
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <GoogleMap />
</template>

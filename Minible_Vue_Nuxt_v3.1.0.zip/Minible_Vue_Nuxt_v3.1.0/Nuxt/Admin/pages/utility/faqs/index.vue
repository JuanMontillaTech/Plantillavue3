<script>
import UtilityFAQComponent from "~/components/utility/faqs/index.vue";
export default {
  data() {
    return {
      title: "FAQs",
      items: [
        {
          text: "Utility",
          href: "/"
        },
        {
          text: "FAQs",
          active: true
        }
      ]
    };
  },
  components: {
    UtilityFAQComponent
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <UtilityFAQComponent />
</template>
F
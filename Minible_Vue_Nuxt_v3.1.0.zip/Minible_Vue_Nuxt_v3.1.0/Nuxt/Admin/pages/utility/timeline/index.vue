<script>
import UtilityTimeline from "~/components/utility/timeline/index.vue";
export default {
  data() {
    return {
      title: "Timeline",
      items: [
        {
          text: "Utility",
          href: "/"
        },
        {
          text: "Timeline",
          active: true
        }
      ]
    };
  },
  components: {
    UtilityTimeline
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <UtilityTimeline />
</template>

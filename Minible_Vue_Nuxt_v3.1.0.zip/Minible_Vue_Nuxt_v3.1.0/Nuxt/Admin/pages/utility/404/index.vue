<script>
import Utility404 from "~/components/utility/404/index.vue";
definePageMeta({
  layout: "utility"
});
export default {
  data() {
    return {
      title: "Error-404"
    };
  },
  components: {
    Utility404
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <Utility404 />
</template>

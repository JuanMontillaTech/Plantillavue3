<script>
import UtilityPricing from "~/components/utility/pricing/index.vue";

export default {
  data() {
    return {
      title: "Pricing",
      items: [
        {
          text: "Utility",
          href: "/"
        },
        {
          text: "Pricing",
          active: true
        }
      ]
    };
  },
  components: {
    UtilityPricing
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <UtilityPricing />
</template>

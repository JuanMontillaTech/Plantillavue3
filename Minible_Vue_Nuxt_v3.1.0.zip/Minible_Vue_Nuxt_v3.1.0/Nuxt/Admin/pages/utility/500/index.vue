<script>
import Utility500 from "~/components/utility/500/index.vue";
definePageMeta({
  layout: "utility"
});
export default {
  data() {
    return {
      title: "Error-500"
    };
  },
  components: {
    Utility500
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <Utility500 />
</template>

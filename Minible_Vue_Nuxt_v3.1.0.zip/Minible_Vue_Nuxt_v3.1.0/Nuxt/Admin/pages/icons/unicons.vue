<script>
import UniconIcons from "~/components/icons/unicons/index.vue";
export default {
  data() {
    return {
      title: "Unicons",
      items: [
        {
          text: "Icons"
        },
        {
          text: "Unicons",
          active: true
        }
      ]
    };
  },
  components: {
    UniconIcons
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <UniconIcons />
</template>

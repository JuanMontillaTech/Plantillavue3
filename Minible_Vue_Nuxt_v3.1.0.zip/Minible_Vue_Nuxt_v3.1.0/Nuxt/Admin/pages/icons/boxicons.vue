<script>
import BoxIcons from "~/components/icons/boxicons/index.vue";
export default {
  data() {
    return {
      title: "Boxicons",
      items: [
        {
          text: "Icons"
        },
        {
          text: "Boxicons",
          active: true
        }
      ]
    };
  },
  components: {
    BoxIcons
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <BoxIcons />
</template>

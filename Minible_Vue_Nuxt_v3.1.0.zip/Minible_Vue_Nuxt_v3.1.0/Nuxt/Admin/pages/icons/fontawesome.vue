<script>
import FontAwesomeIcon from "~/components/icons/fontAwesome/index.vue";
export default {
  data() {
    return {
      title: "Font Awesome",
      items: [
        {
          text: "Icons"
        },
        {
          text: "Font Awesome",
          active: true
        }
      ]
    };
  },
  components: {
    FontAwesomeIcon
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <FontAwesomeIcon />
</template>

<script>
import MaterialDesignIcons from "~/components/icons/materialDesign/index.vue";
export default {
  data() {
    return {
      title: "Material Design",
      items: [
        {
          text: "Icons"
        },
        {
          text: "Material Design",
          active: true
        }
      ]
    };
  },
  components: {
    MaterialDesignIcons
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <MaterialDesignIcons />
</template>

<script>
import DripIcons from "~/components/icons/dripIcons/index.vue";
export default {
  data() {
    return {
      title: "Dripicons",
      items: [
        {
          text: "Icons"
        },
        {
          text: "Dripicons",
          active: true
        }
      ]
    };
  },
  components: {
    DripIcons
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <DripIcons />
</template>

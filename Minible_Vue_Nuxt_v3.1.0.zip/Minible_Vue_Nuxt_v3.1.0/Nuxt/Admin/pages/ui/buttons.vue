<script>
import ButtonUI from "~/components/uiComponents/buttons/index.vue";
export default {
  data() {
    return {
      title: "Buttons",
      items: [
        {
          text: "UI Elements"
        },
        {
          text: "Buttons",
          active: true
        }
      ]
    };
  },
  components: {
    ButtonUI
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <ButtonUI />
</template>

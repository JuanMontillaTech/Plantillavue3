<script>
import TypographyUI from "~/components/uiComponents/typography/index.vue";
export default {
  data() {
    return {
      title: "Typography",
      items: [
        {
          text: "UI Elements"
        },
        {
          text: "Typography",
          active: true
        }
      ]
    };
  },
  components: {
    TypographyUI
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <TypographyUI />
</template>

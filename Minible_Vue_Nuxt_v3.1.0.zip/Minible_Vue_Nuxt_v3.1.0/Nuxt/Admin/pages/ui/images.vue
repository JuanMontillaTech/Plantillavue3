<script>
import ImagesUI from "~/components/uiComponents/images/index.vue";
export default {
  data() {
    return {
      title: "Images",
      items: [
        {
          text: "UI Elements"
        },
        {
          text: "Images",
          active: true
        }
      ]
    };
  },
  components: {
    ImagesUI
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <ImagesUI />
</template>

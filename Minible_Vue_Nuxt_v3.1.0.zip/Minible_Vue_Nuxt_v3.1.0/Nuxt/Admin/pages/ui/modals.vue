<script>
import ModalsUI from "~/components/uiComponents/modals/index.vue";
export default {
  data() {
    return {
      title: "Modals",
      items: [
        {
          text: "UI Elements"
        },
        {
          text: "Modals",
          active: true
        }
      ]
    };
  },
  components: {
    ModalsUI
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <ModalsUI />
</template>

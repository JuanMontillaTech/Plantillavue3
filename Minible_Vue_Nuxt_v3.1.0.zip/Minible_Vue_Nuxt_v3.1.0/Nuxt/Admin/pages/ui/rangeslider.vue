<script>
import RangeSliderUI from "~/components/uiComponents/rangeSlider/index.vue";
export default {
  data() {
    return {
      title: "Range Slider",
      items: [
        {
          text: "UI Elements"
        },
        {
          text: "Range Slider",
          active: true
        }
      ]
    };
  },
  components: {
    RangeSliderUI
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <RangeSliderUI />
</template>

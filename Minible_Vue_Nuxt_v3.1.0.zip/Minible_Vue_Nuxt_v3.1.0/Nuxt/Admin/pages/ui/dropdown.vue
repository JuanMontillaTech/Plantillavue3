<script>
import DropdownUI from "~/components/uiComponents/dropdown/index.vue";
export default {
  data() {
    return {
      title: "Dropdowns",
      items: [
        {
          text: "UI Elements"
        },
        {
          text: "Dropdowns",
          active: true
        }
      ]
    };
  },
  components: {
    DropdownUI
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <DropdownUI />
</template>

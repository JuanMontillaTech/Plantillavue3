<script>
import LightboxUI from "~/components/uiComponents/lightbox/index.vue";
export default {
  data() {
    return {
      title: "Lightbox",
      items: [
        {
          text: "UI Elements"
        },
        {
          text: "Lightbox",
          active: true
        }
      ]
    };
  },
  components: {
    LightboxUI
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <LightboxUI />
</template>

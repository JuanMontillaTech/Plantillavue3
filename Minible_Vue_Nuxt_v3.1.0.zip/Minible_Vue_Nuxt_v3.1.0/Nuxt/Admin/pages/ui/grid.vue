<script>
import GridUI from "~/components/uiComponents/grid/index.vue";
export default {
  data() {
    return {
      title: "Grid",
      items: [
        {
          text: "UI Elements"
        },
        {
          text: "Grid",
          active: true
        }
      ]
    };
  },
  components: {
    GridUI
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <GridUI />
</template>

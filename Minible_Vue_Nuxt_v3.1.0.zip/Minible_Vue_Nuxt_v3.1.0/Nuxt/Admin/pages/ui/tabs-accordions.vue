<script>
import TabsAccordionsUI from "~/components/uiComponents/tabsAccordions/index.vue";
export default {
  data() {
    return {
      title: "Tabs & Accordions",
      items: [
        {
          text: "UI Elements"
        },
        {
          text: "Tabs & Accordions",
          active: true
        }
      ]
    };
  },
  components: {
    TabsAccordionsUI
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <TabsAccordionsUI />
</template>

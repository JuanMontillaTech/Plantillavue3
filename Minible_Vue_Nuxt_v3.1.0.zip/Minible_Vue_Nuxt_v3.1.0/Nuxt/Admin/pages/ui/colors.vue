<script>
import ColorUI from "~/components/uiComponents/colors/index.vue";
export default {
  data() {
    return {
      title: "Colors",
      items: [
        {
          text: "UI Elements"
        },
        {
          text: "Colors",
          active: true
        }
      ]
    };
  },
  components: {
    ColorUI
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <ColorUI />
</template>

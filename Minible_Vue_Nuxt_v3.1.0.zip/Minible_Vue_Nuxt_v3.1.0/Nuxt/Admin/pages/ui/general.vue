<script>
import GeneralUI from "~/components/uiComponents/general/index.vue";
export default {
  data() {
    return {
      title: "General",
      items: [
        {
          text: "UI Elements"
        },
        {
          text: "General",
          active: true
        }
      ]
    };
  },
  components: {
    GeneralUI
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <GeneralUI />
</template>

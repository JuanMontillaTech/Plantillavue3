<script>
import SweetAlertUI from "~/components/uiComponents/sweetAlert/index.vue";
export default {
  data() {
    return {
      title: "SweetAlert 2",
      items: [
        {
          text: "UI Elements"
        },
        {
          text: "SweetAlert 2",
          active: true
        }
      ]
    };
  },
  components: {
    SweetAlertUI
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <SweetAlertUI />
</template>

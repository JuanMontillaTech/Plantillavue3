<script>
import CardUI from "~/components/uiComponents/cards/index.vue";
export default {
  data() {
    return {
      title: "Cards",
      items: [
        {
          text: "UI Elements"
        },
        {
          text: "Cards",
          active: true
        }
      ]
    };
  },
  components: {
    CardUI
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <CardUI />
</template>

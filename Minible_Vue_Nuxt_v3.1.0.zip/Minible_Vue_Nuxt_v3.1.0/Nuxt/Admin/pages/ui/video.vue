<script>
import VideoUI from "~/components/uiComponents/video/index.vue";
export default {
  data() {
    return {
      title: "Video",
      items: [
        {
          text: "UI Elements"
        },
        {
          text: "Video",
          active: true
        }
      ]
    };
  },
  components: {
    VideoUI
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <VideoUI />
</template>

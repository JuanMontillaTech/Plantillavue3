<script>
import PlaceholderUI from "~/components/uiComponents/placeholder/index.vue";
export default {
  data() {
    return {
      title: "Placeholder",
      items: [
        {
          text: "UI Elements"
        },
        {
          text: "Placeholder",
          active: true
        }
      ]
    };
  },
  components: {
    PlaceholderUI
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <PlaceholderUI />
</template>

<script>
import Alert from "~/components/uiComponents/alert/index.vue";
export default {
  data() {
    return {
      title: "Alerts",
      items: [
        {
          text: "UI Elements"
        },
        {
          text: "Alerts",
          active: true
        }
      ]
    };
  },
  components: {
    Alert
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <Alert />
</template>

<script>
import ProgressBarUI from "~/components/uiComponents/progressBar/index.vue";
export default {
  data() {
    return {
      title: "Progress Bars",
      items: [
        {
          text: "UI Elements"
        },
        {
          text: "Progress Bars",
          active: true
        }
      ]
    };
  },
  components: {
    ProgressBarUI
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <ProgressBarUI />
</template>

<script>
import CarouselUI from "~/components/uiComponents/carousel/index.vue";
export default {
  data() {
    return {
      title: "Carousel",
      items: [
        {
          text: "UI Elements"
        },
        {
          text: "Carousel",
          active: true
        }
      ]
    };
  },
  components: {
    CarouselUI
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <CarouselUI />
</template>

<script>
import ContactGridComponent from "~/components/contacts/grid/index.vue";
export default {
  data() {
    return {
      title: "User Grid",
      items: [
        {
          text: "Contacts"
        },
        {
          text: "User Grid",
          active: true
        }
      ]
    };
  },
  components: {
    ContactGridComponent
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <ContactGridComponent />
</template>

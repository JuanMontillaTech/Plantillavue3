<script>
import ContactsProfileComponent from "~/components/contacts/profile/index.vue";

export default {
  data() {
    return {
      title: "Profile",
      items: [
        {
          text: "Contacts"
        },
        {
          text: "Profile",
          active: true
        }
      ]
    };
  },
  components: {
    ContactsProfileComponent
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <ContactsProfileComponent />
</template>

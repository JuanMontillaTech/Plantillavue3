<script>
import ContactsListComponent from "~/components/contacts/list/index.vue";
export default {
  data() {
    return {
      title: "User List",
      items: [
        {
          text: "Contacts"
        },
        {
          text: "User List",
          active: true
        }
      ]
    };
  },
  components: {
    ContactsListComponent
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <ContactsListComponent />
</template>

<script>
import InboxComponent from "~/components/email/inbox/index.vue";

export default {
  data() {
    return {
      title: "Inbox",
      items: [
        {
          text: "Email"
        },
        {
          text: "Inbox",
          active: true
        }
      ]
    };
  },
  components: {
    InboxComponent
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <InboxComponent />
</template>

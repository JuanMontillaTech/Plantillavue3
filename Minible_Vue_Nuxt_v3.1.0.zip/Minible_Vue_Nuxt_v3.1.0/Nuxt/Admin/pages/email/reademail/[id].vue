<script>
import ReadEmailComponent from "~/components/email/readEmail/index.vue";

export default {
  data() {
    return {
      title: "Read Email",
      items: [
        {
          text: "Email",
          href: "/"
        },
        {
          text: "Read Email",
          active: true
        }
      ]
    };
  },
  components: {
    ReadEmailComponent
  },
  computed: {
    emailId() {
      return Number(this.$route.params.id);
    }
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <ReadEmailComponent v-if="emailId" :emailId="emailId" />
</template>

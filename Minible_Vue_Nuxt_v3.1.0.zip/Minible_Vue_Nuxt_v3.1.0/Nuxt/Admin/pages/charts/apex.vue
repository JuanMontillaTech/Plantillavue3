<script>
import ApexChart from "~/components/charts/apex/index.vue";
export default {
  data() {
    return {
      title: "Apex charts",
      items: [
        {
          text: "Charts",
          href: "/"
        },
        {
          text: "Apex charts",
          active: true
        }
      ]
    };
  },
  components: {
    ApexChart
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <ApexChart />
</template>

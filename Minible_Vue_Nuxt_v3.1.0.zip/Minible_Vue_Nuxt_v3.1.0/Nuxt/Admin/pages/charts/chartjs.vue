<script>
import ChartJs from "~/components/charts/chartjs/index.vue";
export default {
  data() {
    return {
      title: "Chartjs Chart",
      items: [
        {
          text: "Charts",
          href: "/"
        },
        {
          text: "Chartjs Chart",
          active: true
        }
      ]
    };
  },
  components: {
    ChartJs
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <ChartJs />
</template>

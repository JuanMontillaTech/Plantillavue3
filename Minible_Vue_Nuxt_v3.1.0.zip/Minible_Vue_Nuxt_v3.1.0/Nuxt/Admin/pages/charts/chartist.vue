<script>
import Chartist from "~/components/charts/chartist/index.vue";
export default {
  data() {
    return {
      title: "Chartist Charts",
      items: [
        {
          text: "Charts",
          href: "/"
        },
        {
          text: "Chartist Charts",
          active: true
        }
      ]
    };
  },
  components: {
    Chartist
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <Chartist />
</template>

<script>
import EChart from "~/components/charts/eChart/index.vue";
export default {
  data() {
    return {
      title: "ECharts",
      items: [
        {
          text: "Charts",
          href: "/"
        },
        {
          text: "ECharts",
          active: true
        }
      ]
    };
  },
  components: {
    EChart
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <EChart />
</template>

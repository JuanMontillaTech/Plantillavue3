<script>
import AdvancedTable from "~/components/tables/advanced/index.vue";
export default {
  data() {
    return {
      title: "Advanced",
      items: [
        {
          text: "Tables"
        },
        {
          text: "Advanced",
          active: true
        }
      ]
    };
  },
  components: {
    AdvancedTable
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <AdvancedTable />
</template>

<script>
import BasicTable from "~/components/tables/basic/index.vue";
export default {
  data() {
    return {
      title: "Bootstrap Basic",
      items: [
        {
          text: "Tables"
        },
        {
          text: "Bootstrap Basic",
          active: true
        }
      ]
    };
  },
  components: {
    BasicTable
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <BasicTable />
</template>

<script>
import ChatComponent from "~/components/chat/index.vue";

export default {
  data() {
    return {
      title: "Chat",
      items: [
        {
          text: "Apps",
          to: "/"
        },
        {
          text: "Chat",
          active: true
        }
      ]
    };
  },
  components: {
    ChatComponent
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <ChatComponent />
</template>

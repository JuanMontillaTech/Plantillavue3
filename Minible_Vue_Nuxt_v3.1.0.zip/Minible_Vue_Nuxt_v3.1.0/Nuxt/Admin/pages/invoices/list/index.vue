<script>
import InvoiceListComponent from "~/components/invoices/list/index.vue";
export default {
  data() {
    return {
      title: "Invoice List",
      items: [
        {
          text: "Invoices"
        },
        {
          text: "Invoice List",
          active: true
        }
      ]
    };
  },
  components: {
    InvoiceListComponent
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <InvoiceListComponent />
</template>

<script>
import InvoiceDetailComponent from "~/components/invoices/detail/index.vue";

export default {
  data() {
    return {
      title: "Invoice Detail",
      items: [
        {
          text: "Invoices"
        },
        {
          text: "Invoice Detail",
          active: true
        }
      ]
    };
  },
  components: {
    InvoiceDetailComponent
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <InvoiceDetailComponent />
</template>

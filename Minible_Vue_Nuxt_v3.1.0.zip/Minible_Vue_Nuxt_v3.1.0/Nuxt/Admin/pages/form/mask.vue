<script>
import MaskForm from "~/components/form/mask/index.vue";
export default {
  data() {
    return {
      title: "Form Mask",
      items: [
        {
          text: "Forms",
          href: "/"
        },
        {
          text: "Form Mask",
          active: true
        }
      ]
    };
  },
  components: {
    MaskForm
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <MaskForm />
</template>

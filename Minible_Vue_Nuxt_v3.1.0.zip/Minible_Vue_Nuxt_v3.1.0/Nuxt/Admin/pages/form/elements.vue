<script>
import ElementsForm from "~/components/form/elements/index.vue";
export default {
  data() {
    return {
      title: "Basic Elements",
      items: [
        {
          text: "Forms",
          href: "/"
        },
        {
          text: "Basic Elements",
          active: true
        }
      ]
    };
  },
  components: {
    ElementsForm
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <ElementsForm />
</template>

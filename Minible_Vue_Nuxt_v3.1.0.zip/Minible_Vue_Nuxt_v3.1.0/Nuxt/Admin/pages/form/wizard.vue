<script>
import WizardForm from "~/components/form/wizard/index.vue";
export default {
  data() {
    return {
      title: "Form Wizard",
      items: [
        {
          text: "Forms",
          href: "/"
        },
        {
          text: "Form Wizard",
          active: true
        }
      ]
    };
  },
  components: {
    WizardForm
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <WizardForm />
</template>

<script>
import ValidationForm from "~/components/form/validation/index.vue";
export default {
  data() {
    return {
      title: "Form Validation",
      items: [
        {
          text: "Forms",
          href: "/"
        },
        {
          text: "Validation",
          active: true
        }
      ]
    };
  },
  components: {
    ValidationForm
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <ValidationForm />
</template>

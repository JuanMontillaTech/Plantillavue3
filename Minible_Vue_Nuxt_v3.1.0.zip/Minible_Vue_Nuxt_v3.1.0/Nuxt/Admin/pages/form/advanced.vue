<script>
import AdvanceForm from "~/components/form/advanced/index.vue";
export default {
  data() {
    return {
      title: "Form Advanced",
      items: [
        {
          text: "Forms",
          href: "/"
        },
        {
          text: "Advanced",
          active: true
        }
      ]
    };
  },
  components: {
    AdvanceForm
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <AdvanceForm />
</template>

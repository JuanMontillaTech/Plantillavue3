<script>
import EditorForm from "~/components/form/editor/index.vue";
export default {
  data() {
    return {
      title: "Form editor",
      items: [
        {
          text: "Forms",
          href: "/"
        },
        {
          text: "Form editor",
          active: true
        }
      ]
    };
  },
  components: {
    EditorForm
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <EditorForm />
</template>

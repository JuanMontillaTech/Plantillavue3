<script>
import UploadForm from "~/components/form/upload/index.vue";
export default {
  data() {
    return {
      title: "Form File Upload",
      items: [
        {
          text: "Forms",
          href: "/"
        },
        {
          text: "Form File Upload",
          active: true
        }
      ]
    };
  },
  components: {
    UploadForm
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <UploadForm />
</template>

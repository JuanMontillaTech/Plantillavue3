<script>
import RepeaterForm from "~/components/form/repeater/index.vue";
export default {
  data() {
    return {
      title: "Form Repeater",
      items: [
        {
          text: "Forms",
          href: "/"
        },
        {
          text: "Form Repeater",
          active: true
        }
      ]
    };
  },
  components: {
    RepeaterForm
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <RepeaterForm />
</template>

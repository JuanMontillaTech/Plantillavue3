<script>
import CheckoutComponent from "~/components/eCommerce/checkout/index.vue";
export default {
  data() {
    return {
      title: "Checkout",
      items: [
        {
          text: "Ecommerce"
        },
        {
          text: "Checkout",
          active: true
        }
      ]
    };
  },
  components: {
    CheckoutComponent
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <CheckoutComponent />
</template>

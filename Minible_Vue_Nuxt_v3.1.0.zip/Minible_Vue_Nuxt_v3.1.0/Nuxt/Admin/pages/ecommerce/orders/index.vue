<script>
import OrdersComponent from "~/components/eCommerce/orders/index.vue";

export default {
  data() {
    return {
      title: "Orders",
      items: [
        {
          text: "Ecommerce"
        },
        {
          text: "Orders",
          active: true
        }
      ]
    };
  },
  components: {
    OrdersComponent
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <OrdersComponent />
</template>

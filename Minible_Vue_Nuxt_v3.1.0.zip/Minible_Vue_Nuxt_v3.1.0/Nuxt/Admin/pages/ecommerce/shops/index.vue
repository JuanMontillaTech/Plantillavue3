<script>
import ShopsComponent from "~/components/eCommerce/shops/index.vue";
export default {
  data() {
    return {
      title: "Shops",
      items: [
        {
          text: "Ecommerce"
        },
        {
          text: "Shops",
          active: true
        }
      ]
    };
  },
  components: {
    ShopsComponent
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <ShopsComponent />
</template>

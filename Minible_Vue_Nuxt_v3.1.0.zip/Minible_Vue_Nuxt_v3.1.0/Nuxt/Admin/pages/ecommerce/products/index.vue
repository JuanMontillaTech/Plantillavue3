<script>
import ProductComponent from "~/components/eCommerce/Products/index.vue";

export default {
  data() {
    return {
      title: "Products",
      items: [
        {
          text: "Ecommerce"
        },
        {
          text: "Products",
          active: true
        }
      ]
    };
  },
  components: {
    ProductComponent
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <ProductComponent />
</template>

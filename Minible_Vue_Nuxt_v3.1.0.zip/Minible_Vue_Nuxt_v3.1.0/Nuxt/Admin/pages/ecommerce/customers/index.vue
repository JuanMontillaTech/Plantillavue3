<script>
import CustomersComponent from "~/components/eCommerce/customers/index.vue";
export default {
  data() {
    return {
      title: "Customers",
      items: [
        {
          text: "Ecommerce"
        },
        {
          text: "Customers",
          active: true
        }
      ]
    };
  },
  components: {
    CustomersComponent
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <CustomersComponent />
</template>

<script>
import AddProductComponent from "~/components/eCommerce/addProduct/index.vue";

export default {
  data() {
    return {
      title: "Add Product",
      items: [
        {
          text: "Ecommerce"
        },
        {
          text: "Add Product",
          active: true
        }
      ]
    };
  },
  components: {
    AddProductComponent
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <AddProductComponent />
</template>

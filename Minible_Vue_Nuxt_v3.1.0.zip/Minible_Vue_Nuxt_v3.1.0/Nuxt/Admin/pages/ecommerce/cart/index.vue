<script>
import CartComponent from "~/components/eCommerce/cart/index.vue";

export default {
  data() {
    return {
      title: "Cart",
      items: [
        {
          text: "Ecommerce"
        },
        {
          text: "Cart",
          active: true
        }
      ]
    };
  },
  components: {
    CartComponent
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <CartComponent />
</template>

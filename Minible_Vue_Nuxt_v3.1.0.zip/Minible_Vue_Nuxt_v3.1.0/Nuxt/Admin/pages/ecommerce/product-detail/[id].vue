<script>
import ProductDetailById from "~/components/eCommerce/productDetail/ProductDetailById.vue";
export default {
  data() {
    return {
      title: "Product Detail",
      items: [
        {
          text: "Ecommerce"
        },
        {
          text: "Product Detail",
          active: true
        }
      ]
    };
  },
  computed: {
    productId() {
      return Number(this.$route.params.id);
    }
  },
  components: {
    ProductDetailById
  }
};
</script>

<template>
  <SiteHeader :title="title" />
  <PageHeader :title="title" :items="items" />
  <ProductDetailById v-if="productId" :productId="productId" />
</template>
